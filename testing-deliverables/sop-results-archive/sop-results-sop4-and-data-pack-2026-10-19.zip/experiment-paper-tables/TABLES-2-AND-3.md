# Experiment Paper tables: Table 2 (Instrument 2) and Table 3 (Instrument 3)

Generated from recorded data (`python -m sop.chapter4 --tables`). The table headings, columns and markers are the **approved** ones; only the cells are filled.
Tables 1 and 4 are in `TABLES-1-AND-4.md`. Statistics behind these tables: `STATISTICS.md`. How to use them in Chapters 4 and 5: `SOP-MAP-AND-CLAIMS.md`.

| Table | Serves | Equations | Draft section |
|---|---|---|---|
| 2 | SOP 5 (systemic performance), SOP 1 (wire bytes), SOP 2 (per-block decryption) | Eq. 1, 2, 5; paired t-test; Eq. 3 | 4.7 |
| 3 | SOP 4 (offloading), SOP 2 (encapsulation) | Eq. 1, 2, 5 | 4.6.1 |

## How to read Table 2
- **Cycle n = the n-th complete A/B pair.** A pair is a trial number that both Scenario A and Scenario B finished successfully; a failed cycle has no completion time, so it is not a pair.
  Table cycle to campaign trial number: 1=1, 2=2, 3=3, 4=4, 5=5, 6=6, 7=8, 8=9, 9=10, 10=12, 11=13, 12=14, 13=16, 14=17, 15=18, 16=19, 17=20, 18=22, 19=23, 20=24, 21=25, 22=26, 23=27, 24=28, 25=29, 26=30, 27=31, 28=32, 29=33, 30=35, 31=36, 32=37, 33=38, 34=39, 35=40, 36=41, 37=42, 38=44, 39=45, 40=46, 41=47, 42=48, 43=49, 44=50, 45=51, 46=53, 47=54, 48=55, 49=56, 50=57, 51=58, 52=59, 53=60, 54=61, 55=63, 56=64, 57=65, 58=67, 59=68, 60=69.
- **Wireshark TTC** = first device `GET /patch` to the gateway's last `2.04` in the same capture (tshark on the gateway PC).
- **ESP32 Peak RAM** = static RAM of our update technology (updater image minus the Wi-Fi-only control, 28.73 KB). It is a build property, so it is the same in every row and its SD is 0 (no t-test). The measured heap peak is reported separately in `STATISTICS.md`.
- **Decryption + Reconstruction** = device AES-CCM time plus the delta decoder time (inflate, merge with the old flash, flash writes), from the `[Metrics2]` serial line. Scenario B is **N/A** by the approved layout; its measured value is in `data/ab_pairs.csv`.
- **Flash write throughput** = bytes written by `esp_ota_write` over the time spent in `esp_ota_begin` plus `esp_ota_write`.
- **STAT rows** = Equation 1 (mean) and Equation 2 (sample standard deviation) per scenario.

**Table 2. Continuous Metrics for Hardware and Network Performance**

| Cycle # | Scenario Type | Wireshark TTC (ms) | ESP32 Peak Ram Allocation (KB) | Decryption + Reconstruction Time (ms) | Total Flash Write Throughput (KB/s) |
|---|---|---|---|---|---|
| 1 | A (Delta-OTA) | 5308.6 | 28.73 | 1756.3 | 184.0 |
| 1 | B (Full-Binary) | 34262.0 | 28.73 | N/A | 197.1 |
| 2 | A (Delta-OTA) | 5291.2 | 28.73 | 1763.3 | 183.1 |
| 2 | B (Full-Binary) | 34262.6 | 28.73 | N/A | 197.0 |
| 3 | A (Delta-OTA) | 5276.9 | 28.73 | 1731.3 | 187.1 |
| 3 | B (Full-Binary) | 34071.3 | 28.73 | N/A | 195.7 |
| 4 | A (Delta-OTA) | 5290.1 | 28.73 | 1763.7 | 183.1 |
| 4 | B (Full-Binary) | 34387.8 | 28.73 | N/A | 197.5 |
| 5 | A (Delta-OTA) | 5309.3 | 28.73 | 1772.2 | 182.2 |
| 5 | B (Full-Binary) | 34286.4 | 28.73 | N/A | 194.3 |
| 6 | A (Delta-OTA) | 5312.3 | 28.73 | 1760.6 | 183.4 |
| 6 | B (Full-Binary) | 34071.0 | 28.73 | N/A | 196.0 |
| 7 | A (Delta-OTA) | 5393.9 | 28.73 | 1728.6 | 187.4 |
| 7 | B (Full-Binary) | 34049.3 | 28.73 | N/A | 198.1 |
| 8 | A (Delta-OTA) | 14779.1 | 28.73 | 1777.6 | 181.5 |
| 8 | B (Full-Binary) | 42753.6 | 28.73 | N/A | 197.9 |
| 9 | A (Delta-OTA) | 5385.9 | 28.73 | 1757.9 | 183.9 |
| 9 | B (Full-Binary) | 34058.6 | 28.73 | N/A | 197.5 |
| 10 | A (Delta-OTA) | 6093.2 | 28.73 | 1743.1 | 185.5 |
| 10 | B (Full-Binary) | 43076.2 | 28.73 | N/A | 196.3 |
| 11 | A (Delta-OTA) | 5288.3 | 28.73 | 1751.6 | 184.6 |
| 11 | B (Full-Binary) | 34059.9 | 28.73 | N/A | 197.5 |
| 12 | A (Delta-OTA) | 5453.9 | 28.73 | 1746.4 | 185.1 |
| 12 | B (Full-Binary) | 37292.2 | 28.73 | N/A | 194.7 |
| 13 | A (Delta-OTA) | 5285.5 | 28.73 | 1737.2 | 186.3 |
| 13 | B (Full-Binary) | 34070.9 | 28.73 | N/A | 196.5 |
| 14 | A (Delta-OTA) | 5314.2 | 28.73 | 1780.3 | 181.1 |
| 14 | B (Full-Binary) | 34101.3 | 28.73 | N/A | 192.1 |
| 15 | A (Delta-OTA) | 5346.6 | 28.73 | 1752.3 | 184.5 |
| 15 | B (Full-Binary) | 34278.6 | 28.73 | N/A | 194.8 |
| 16 | A (Delta-OTA) | 5297.0 | 28.73 | 1771.4 | 182.2 |
| 16 | B (Full-Binary) | 40653.9 | 28.73 | N/A | 198.6 |
| 17 | A (Delta-OTA) | 5543.4 | 28.73 | 1782.7 | 181.0 |
| 17 | B (Full-Binary) | 34117.8 | 28.73 | N/A | 191.4 |
| 18 | A (Delta-OTA) | 5503.1 | 28.73 | 1744.7 | 185.3 |
| 18 | B (Full-Binary) | 34068.3 | 28.73 | N/A | 196.0 |
| 19 | A (Delta-OTA) | 5280.7 | 28.73 | 1754.0 | 184.4 |
| 19 | B (Full-Binary) | 40742.9 | 28.73 | N/A | 195.7 |
| 20 | A (Delta-OTA) | 5286.1 | 28.73 | 1762.7 | 183.2 |
| 20 | B (Full-Binary) | 34085.0 | 28.73 | N/A | 194.3 |
| 21 | A (Delta-OTA) | 5296.4 | 28.73 | 1766.6 | 182.8 |
| 21 | B (Full-Binary) | 34355.1 | 28.73 | N/A | 198.4 |
| 22 | A (Delta-OTA) | 5303.2 | 28.73 | 1781.7 | 181.0 |
| 22 | B (Full-Binary) | 34070.9 | 28.73 | N/A | 195.6 |
| 23 | A (Delta-OTA) | 5605.7 | 28.73 | 1734.7 | 186.7 |
| 23 | B (Full-Binary) | 34460.3 | 28.73 | N/A | 198.0 |
| 24 | A (Delta-OTA) | 5293.2 | 28.73 | 1745.4 | 185.3 |
| 24 | B (Full-Binary) | 40655.6 | 28.73 | N/A | 198.4 |
| 25 | A (Delta-OTA) | 5284.0 | 28.73 | 1755.7 | 184.0 |
| 25 | B (Full-Binary) | 34063.1 | 28.73 | N/A | 197.3 |
| 26 | A (Delta-OTA) | 5515.9 | 28.73 | 1743.3 | 185.7 |
| 26 | B (Full-Binary) | 34047.4 | 28.73 | N/A | 199.1 |
| 27 | A (Delta-OTA) | 5489.5 | 28.73 | 1766.3 | 182.7 |
| 27 | B (Full-Binary) | 88674.7 | 28.73 | N/A | 196.3 |
| 28 | A (Delta-OTA) | 5278.0 | 28.73 | 1753.3 | 184.3 |
| 28 | B (Full-Binary) | 34042.1 | 28.73 | N/A | 200.1 |
| 29 | A (Delta-OTA) | 5263.3 | 28.73 | 1733.6 | 186.8 |
| 29 | B (Full-Binary) | 34109.9 | 28.73 | N/A | 198.0 |
| 30 | A (Delta-OTA) | 5323.1 | 28.73 | 1760.0 | 183.5 |
| 30 | B (Full-Binary) | 34080.5 | 28.73 | N/A | 195.8 |
| 31 | A (Delta-OTA) | 5319.9 | 28.73 | 1780.6 | 181.1 |
| 31 | B (Full-Binary) | 40924.8 | 28.73 | N/A | 197.5 |
| 32 | A (Delta-OTA) | 5303.7 | 28.73 | 1755.5 | 184.1 |
| 32 | B (Full-Binary) | 34093.9 | 28.73 | N/A | 192.6 |
| 33 | A (Delta-OTA) | 5895.9 | 28.73 | 1763.1 | 183.2 |
| 33 | B (Full-Binary) | 34858.3 | 28.73 | N/A | 198.4 |
| 34 | A (Delta-OTA) | 5316.4 | 28.73 | 1770.8 | 182.3 |
| 34 | B (Full-Binary) | 34083.1 | 28.73 | N/A | 194.4 |
| 35 | A (Delta-OTA) | 5863.1 | 28.73 | 1722.4 | 188.2 |
| 35 | B (Full-Binary) | 34077.5 | 28.73 | N/A | 195.8 |
| 36 | A (Delta-OTA) | 5287.7 | 28.73 | 1736.6 | 186.3 |
| 36 | B (Full-Binary) | 34067.3 | 28.73 | N/A | 195.9 |
| 37 | A (Delta-OTA) | 5300.0 | 28.73 | 1750.7 | 184.6 |
| 37 | B (Full-Binary) | 34124.2 | 28.73 | N/A | 196.7 |
| 38 | A (Delta-OTA) | 5521.8 | 28.73 | 1735.3 | 186.7 |
| 38 | B (Full-Binary) | 42671.7 | 28.73 | N/A | 197.1 |
| 39 | A (Delta-OTA) | 5486.4 | 28.73 | 1784.9 | 180.6 |
| 39 | B (Full-Binary) | 34053.7 | 28.73 | N/A | 199.4 |
| 40 | A (Delta-OTA) | 5275.3 | 28.73 | 1720.0 | 188.3 |
| 40 | B (Full-Binary) | 41471.2 | 28.73 | N/A | 196.6 |
| 41 | A (Delta-OTA) | 5386.6 | 28.73 | 1754.8 | 184.2 |
| 41 | B (Full-Binary) | 35072.6 | 28.73 | N/A | 197.3 |
| 42 | A (Delta-OTA) | 5898.5 | 28.73 | 1732.8 | 186.9 |
| 42 | B (Full-Binary) | 48291.4 | 28.73 | N/A | 195.4 |
| 43 | A (Delta-OTA) | 5330.7 | 28.73 | 1769.2 | 182.5 |
| 43 | B (Full-Binary) | 35074.3 | 28.73 | N/A | 193.1 |
| 44 | A (Delta-OTA) | 6487.1 | 28.73 | 1756.1 | 184.1 |
| 44 | B (Full-Binary) | 34679.5 | 28.73 | N/A | 195.2 |
| 45 | A (Delta-OTA) | 5293.5 | 28.73 | 1730.5 | 187.2 |
| 45 | B (Full-Binary) | 35117.9 | 28.73 | N/A | 196.9 |
| 46 | A (Delta-OTA) | 5763.9 | 28.73 | 1749.9 | 185.0 |
| 46 | B (Full-Binary) | 64475.4 | 28.73 | N/A | 192.9 |
| 47 | A (Delta-OTA) | 5297.2 | 28.73 | 1748.0 | 184.9 |
| 47 | B (Full-Binary) | 34088.5 | 28.73 | N/A | 194.0 |
| 48 | A (Delta-OTA) | 5305.4 | 28.73 | 1756.3 | 184.1 |
| 48 | B (Full-Binary) | 34281.4 | 28.73 | N/A | 194.2 |
| 49 | A (Delta-OTA) | 5357.1 | 28.73 | 1773.7 | 181.9 |
| 49 | B (Full-Binary) | 34308.7 | 28.73 | N/A | 193.4 |
| 50 | A (Delta-OTA) | 5578.6 | 28.73 | 1756.1 | 184.2 |
| 50 | B (Full-Binary) | 34295.6 | 28.73 | N/A | 192.9 |
| 51 | A (Delta-OTA) | 5489.5 | 28.73 | 1733.6 | 186.7 |
| 51 | B (Full-Binary) | 34491.4 | 28.73 | N/A | 193.0 |
| 52 | A (Delta-OTA) | 5311.3 | 28.73 | 1761.3 | 183.3 |
| 52 | B (Full-Binary) | 34098.8 | 28.73 | N/A | 193.9 |
| 53 | A (Delta-OTA) | 5308.7 | 28.73 | 1755.5 | 184.0 |
| 53 | B (Full-Binary) | 34298.0 | 28.73 | N/A | 193.3 |
| 54 | A (Delta-OTA) | 5290.2 | 28.73 | 1762.0 | 183.3 |
| 54 | B (Full-Binary) | 35073.3 | 28.73 | N/A | 196.1 |
| 55 | A (Delta-OTA) | 5295.8 | 28.73 | 1733.8 | 186.7 |
| 55 | B (Full-Binary) | 34092.2 | 28.73 | N/A | 194.5 |
| 56 | A (Delta-OTA) | 5364.7 | 28.73 | 1759.4 | 183.6 |
| 56 | B (Full-Binary) | 40882.5 | 28.73 | N/A | 195.3 |
| 57 | A (Delta-OTA) | 5346.7 | 28.73 | 1774.0 | 182.0 |
| 57 | B (Full-Binary) | 34101.0 | 28.73 | N/A | 194.2 |
| 58 | A (Delta-OTA) | 5317.2 | 28.73 | 1758.3 | 183.5 |
| 58 | B (Full-Binary) | 34103.1 | 28.73 | N/A | 193.4 |
| 59 | A (Delta-OTA) | 5282.2 | 28.73 | 1726.0 | 187.8 |
| 59 | B (Full-Binary) | 34468.8 | 28.73 | N/A | 198.2 |
| 60 | A (Delta-OTA) | 5297.8 | 28.73 | 1746.0 | 185.3 |
| 60 | B (Full-Binary) | 34080.3 | 28.73 | N/A | 195.0 |
| STAT | Arithmetic Mean (A (Delta-OTA)) | 5571.1 | 28.73 | 1753.9 | 184.3 |
| STAT | Arithmetic Mean (B (Full-Binary)) | 37051.8 | 28.73 | N/A | 195.9 |
| STAT | Standard Deviation (A (Delta-OTA)) | 1230.1 | 0.00 | 16.3 | 2.0 |
| STAT | Standard Deviation (B (Full-Binary)) | 8337.6 | 0.00 | N/A | 2.0 |

*Scenario B's Decryption + Reconstruction cells stay N/A as approved; in this testbed Scenario B also passes the same decrypt path, and its measured values are kept in the raw data.*

### Table 2 provenance
- Campaign data: `C:\Users\jajai\Desktop\DELTA-OTA-UI\sop-results\campaign-AB-full-20261019T025653Z\campaign\trials.csv` (sha256 `84b828a5dd3ec180a0f039b4c8eaa29535b1da84c12869874c9fa7501f14a66a`)
- Counted attempts: A ok 65, failed 4; B ok 64, failed 5; harness-invalid cycles re-run (no update started): A 3, B 3.
- Firmware: factory image `campaign-fw-1` (firmware repo commit 7131621). Controller revisions recorded: 6efe798. Table code revision: 434f253.
- Failed cycles (kept in the raw CSV, listed in `data/failures.csv`): A trial 7: delta decode error (161 s); B trial 11: transfer stalled; A trial 15: delta decode error (161 s); B trial 21: delta decode error (282 s); A trial 34: delta decode error (161 s); B trial 43: delta decode error (282 s); B trial 52: transfer stalled; A trial 62: delta decode error (161 s); B trial 66: transfer stalled.
- Gateway = the development PC (not the Pi); Wi-Fi 2.4 GHz to one ESP32; one version pair (v1.0 to v1.1).

## How to read Table 3
- 60 gateway-only cycles after 3 discarded warm-up cycles, on a Raspberry Pi 4 Model B limited to Raspberry Pi 3B+ memory and clock: `free -m` 905 MB total (1 GB cap, `total_mem=1024`), `arm_freq=1400` (measured 1,400,361,344 Hz), 4 cores, swap enabled (904 MB); recorded on the Pi on 2026-10-19 (before the caps: 3,795 MB and 1,800 MHz).
- **Polling** = mean time of the contract reads since the previous release (a LAN call to the chain on the PC). **SHA-256** and **AES-CCM encapsulation** (24 blocks) are timed with the pyperf clock, garbage collector off.
  **Peak RAM** and **CPU** are psutil samples (50 ms) from detection to staging; CPU is a share of total capacity (4 cores).
- **STAT: Average** = Equation 1. The standard deviations and tolerance limits are in `STATISTICS.md` section 7.

**Table 3. Edge Gateway Computational Overhead and Security Tax Profiling**

| Cycle # | Web3 Smart Contract Polling (ms) | Local SHA-256 Hash Execution (ms) | OSCORE AES-CCM Encapsulation (ms) | Peak Gateway RAM Utilized (MB) | Peak Gateway CPU Load (%) |
|---|---|---|---|---|---|
| 1 | 58.70 | 0.222 | 5.93 | 79.6 | 28.9 |
| 2 | 67.44 | 0.224 | 5.94 | 79.7 | 28.6 |
| 3 | 47.61 | 0.227 | 6.47 | 79.7 | 32.5 |
| 4 | 72.93 | 0.223 | 5.91 | 79.8 | 29.7 |
| 5 | 61.99 | 0.224 | 6.00 | 79.8 | 41.4 |
| 6 | 121.38 | 0.226 | 6.00 | 79.1 | 29.7 |
| 7 | 32.93 | 0.224 | 6.03 | 80.0 | 29.7 |
| 8 | 70.85 | 0.227 | 6.57 | 80.0 | 50.9 |
| 9 | 57.79 | 0.224 | 5.89 | 80.1 | 47.0 |
| 10 | 30.21 | 0.253 | 5.92 | 80.2 | 24.8 |
| 11 | 23.79 | 0.222 | 5.98 | 80.2 | 25.7 |
| 12 | 25.18 | 0.222 | 5.99 | 80.2 | 49.8 |
| 13 | 23.38 | 0.224 | 6.03 | 80.3 | 29.6 |
| 14 | 54.93 | 0.382 | 6.15 | 80.3 | 29.7 |
| 15 | 84.97 | 0.224 | 6.08 | 80.3 | 41.1 |
| 16 | 74.12 | 0.222 | 7.66 | 80.4 | 30.2 |
| 17 | 42.10 | 0.222 | 5.92 | 80.4 | 24.8 |
| 18 | 50.65 | 0.223 | 5.90 | 80.4 | 40.5 |
| 19 | 60.74 | 0.245 | 6.05 | 80.4 | 29.8 |
| 20 | 30.37 | 0.221 | 5.99 | 80.5 | 26.8 |
| 21 | 35.22 | 0.223 | 6.48 | 80.5 | 29.6 |
| 22 | 44.85 | 0.365 | 5.92 | 80.6 | 32.8 |
| 23 | 59.78 | 0.223 | 6.02 | 80.7 | 24.9 |
| 24 | 35.30 | 0.222 | 5.96 | 80.7 | 29.5 |
| 25 | 55.04 | 0.223 | 6.57 | 80.7 | 26.7 |
| 26 | 36.25 | 0.225 | 6.12 | 80.7 | 29.7 |
| 27 | 51.08 | 0.225 | 5.99 | 80.8 | 24.8 |
| 28 | 45.36 | 0.222 | 6.64 | 80.9 | 39.5 |
| 29 | 41.54 | 0.223 | 6.01 | 80.9 | 24.8 |
| 30 | 41.33 | 0.222 | 6.13 | 80.9 | 32.9 |
| 31 | 40.89 | 0.223 | 6.06 | 80.9 | 29.7 |
| 32 | 41.82 | 0.223 | 5.95 | 80.9 | 24.8 |
| 33 | 40.60 | 0.224 | 6.12 | 80.9 | 31.5 |
| 34 | 41.89 | 0.223 | 6.26 | 81.0 | 29.7 |
| 35 | 48.21 | 0.223 | 6.09 | 81.1 | 24.8 |
| 36 | 51.34 | 0.224 | 6.01 | 81.2 | 29.7 |
| 37 | 124.65 | 0.225 | 6.08 | 81.2 | 29.7 |
| 38 | 108.68 | 0.223 | 5.99 | 81.3 | 29.6 |
| 39 | 43.93 | 0.224 | 6.21 | 81.3 | 24.8 |
| 40 | 52.40 | 0.220 | 6.13 | 81.3 | 24.8 |
| 41 | 45.58 | 0.221 | 6.63 | 81.3 | 26.8 |
| 42 | 49.40 | 0.224 | 5.98 | 81.3 | 36.2 |
| 43 | 49.29 | 0.223 | 5.99 | 81.4 | 29.7 |
| 44 | 50.94 | 0.222 | 5.91 | 81.4 | 53.3 |
| 45 | 86.68 | 0.222 | 6.10 | 81.4 | 29.1 |
| 46 | 50.76 | 0.222 | 6.23 | 81.4 | 24.8 |
| 47 | 52.27 | 0.258 | 6.04 | 81.4 | 29.7 |
| 48 | 51.50 | 0.223 | 6.04 | 81.5 | 24.8 |
| 49 | 52.89 | 0.222 | 6.04 | 81.5 | 29.7 |
| 50 | 53.82 | 0.248 | 5.98 | 81.7 | 29.7 |
| 51 | 54.06 | 0.223 | 6.07 | 81.8 | 27.7 |
| 52 | 54.53 | 0.222 | 6.02 | 81.8 | 24.7 |
| 53 | 57.38 | 0.222 | 6.10 | 81.8 | 24.8 |
| 54 | 58.36 | 0.222 | 6.12 | 81.8 | 32.8 |
| 55 | 57.45 | 0.222 | 6.15 | 81.8 | 24.8 |
| 56 | 58.87 | 0.222 | 6.03 | 81.8 | 25.3 |
| 57 | 57.58 | 0.225 | 6.16 | 81.9 | 24.8 |
| 58 | 57.51 | 0.224 | 6.23 | 81.9 | 26.7 |
| 59 | 57.17 | 0.223 | 6.48 | 81.9 | 24.7 |
| 60 | 59.44 | 0.223 | 6.06 | 82.0 | 29.8 |
| STAT: Average | 54.13 | 0.230 | 6.13 | 80.9 | 30.4 |

### Table 3 provenance
- Campaign data: `C:\Users\jajai\Desktop\DELTA-OTA-UI\sop-results\campaign-T3-full-20261019T080000Z\campaign\table3.csv` (sha256 `726f7bd6d4fa62f95e3a2e1a31d254d002fbac393d71dbfd6b56edef64aa564a`), 3 warm-up + 60 counted cycles, all ok.
- Cycle 6 was run twice: the first run had a stalled contract read (an RPC call to the chain on the PC) and is marked superseded in the CSV; the table shows the re-run. The original row is kept in `table3.csv` and in `table3.before-cycle6-rerun.csv`.
- Median polling latency 51.9 ms; maximum 124.7 ms.
- The Pi clock was about 200 s ahead of the PC; only the derived time-to-stage column (not part of the table) is affected.
