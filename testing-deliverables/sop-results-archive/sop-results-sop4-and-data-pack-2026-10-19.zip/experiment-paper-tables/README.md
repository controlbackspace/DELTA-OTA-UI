# Experiment Paper tables: the data pack for Chapters 4 and 5

Everything the group needs to write Chapter 4 (Results and Discussion) and Chapter 5 (Summary, Conclusions, Recommendations) from **recorded data only**.
The four tables are the ones approved in the Experiment Paper. Their layouts, headings and markers are not changed; only the cells are filled.
Last regenerated: 2026-10-19. Everything marked *generated* is rebuilt by one command (see section 6).
This folder is inside `sop-results/`, which git ignores, so it stays on this PC unless it is shared or archived.

## 1. Read these in this order

| # | File | Use it for |
|---|---|---|
| 1 | `SOP-MAP-AND-CLAIMS.md` | Which instrument, equation and result answers which SOP; what we **can** and **cannot** claim; how to present each difference from Chapter 3 (Chapter 3 is not edited) |
| 2 | `TABLES-1-AND-4.md` | **Table 1** (static payload) and **Table 4** (Scenarios C, D, E, Success-Run), approved layout |
| 3 | `TABLES-2-AND-3.md` | **Table 2** (Scenarios A and B, 60 pairs) and **Table 3** (Raspberry Pi gateway, 60 cycles), approved layout, with provenance |
| 4 | `STATISTICS.md` (*generated*) | Every test behind the numbers: Eq. 1 to 6, paired t-test, confidence intervals, tolerance limits, root cause, failures, sensitivity, SOP 4 |
| 5 | `figures/` (*generated*) | Five PNG figures (payload, time to completion, spread, repeated requests, SOP 4) |
| 6 | `DEFENSE-QA.md` | Likely panel questions with honest answers |
| 7 | `../CHAPTERS-4-AND-5-DRAFT.md` | The full draft of Chapters 4 and 5 with the four tables in an appendix |
| 8 | `../sop4-supporting-data/` | Supporting evidence for SOP 4 (on-device Web3 client, heap, static footprint) |

## 2. The headline results (all from the files above)

| Result | Value | Source |
|---|---|---|
| Table 1: delta patch against full image | 22,497 B against 288,880 B: **92.21%** smaller | `TABLES-1-AND-4.md` |
| Time to completion, delta (A) against full binary (B), 60 matched pairs | 5,571.1 ms against 37,051.8 ms: **84.96%** shorter; paired t = -29.49, p = 5.2e-37; A faster in 60 of 60 pairs | `STATISTICS.md` section 3 |
| Bytes on the wire | 27,499 against 198,211: **86.13%** fewer | section 3 |
| 99%/95% worst case (Eq. 5, K = 2.8071) | 9.0 s (A) against 60.5 s (B) | section 3 |
| Decryption + reconstruction | 1,753.9 ms (A); B is "N/A" in the approved Table 2 (raw: 1,845.1 ms) | Table 2 |
| Flash write throughput | 184.3 KB/s (A) and 195.9 KB/s (B): A is **5.9% lower** (significant, unfavourable) | section 3 |
| Static RAM of the technology | 28.73 KB, constant in every cycle (SD 0), 57.4% of 50 KiB | Table 2 |
| Table 3 (Raspberry Pi, 3B+ limits) | polling 54.13 ms, SHA-256 0.230 ms, AES-CCM 6.13 ms, 80.9 MB, 30.4% CPU | `TABLES-2-AND-3.md` |
| Table 4 | 60 of 60 in each of C, D, E; Success-Run C = 1 - 0.95^60 = **95.39%** | `TABLES-1-AND-4.md` |
| Update failures (counted attempts) | 9 of 138 (6.5%): A 4, B 5; not different (Fisher p = 1.0); cause unresolved | section 5 |
| SOP 4, on the board | one on-device ledger check 1,414 ms, 52,000 B heap; offloading cuts peak RAM by 58% and flash by 78.5% | `../sop4-supporting-data/SOP4-SUMMARY.md` |

## 3. How the instruments map to the tables and scenarios

| Table | Instrument | Scenarios | Tools (as approved) | Volume |
|---|---|---|---|---|
| 1 | Volumetric payload (static) | none (one benchmark of the version pair) | bsdiff4 output, file sizes | 1 |
| 2 | Hardware and network telemetry | A (delta) and B (full binary, the internal control) | Wireshark/tshark (TTC), ESP32 serial metrics | 60 matched pairs |
| 3 | Edge gateway overhead and security tax | gateway-only cycles on the Raspberry Pi | pyperf timer, psutil | 60 cycles (+3 warm-up) |
| 4 | Deterministic security validation | C (tampered patch), D (kill switch), E (incomplete signatures) | gateway logs, chain transaction logs | 60 per scenario |

## 4. Things that are easy to get wrong

1. **Cycle n of Table 2 is the n-th complete A/B pair, not trial n.** A trial counts as a pair only when both A and B finished it. Nine counted cycles failed, so trials 61 to 69 were added until 60 pairs existed. `STATISTICS.md` section 2 lists the pair-to-trial mapping.
2. **B's "Decryption + Reconstruction Time" is N/A in Table 2** (approved layout). The measured B value (1,845.1 ms) is in `data/ab_pairs.csv` and is used only to explain the A/B comparison.
3. **ESP32 Peak RAM in Table 2 is the static RAM of our technology** (updater image minus the Wi-Fi-only control), a build property: the same in every row, SD = 0, no t-test. The measured heap peak is separate (`STATISTICS.md` section 3, "Peak heap used during the update"; 58 pairs, because one A and one B cycle lack the marker).
4. **Scenarios A and B used the development PC as the gateway; Table 3 used a Raspberry Pi 4 limited to Raspberry Pi 3B+ specifications** (905 MB visible, 1.4 GHz, 4 cores, swap present). Do not use PC gateway numbers as Table 3 values.
5. **Table 3 cycle 6 was measured twice.** The first run had a stalled contract read; the original row is kept in the raw CSV (`table3.before-cycle6-rerun.csv`) and the table shows the re-run (provenance note under Table 3).
6. **Delta is not better on every metric.** Flash write throughput is 5.9% lower, and the decoder spends 136 ms more per update (it reads the old image). Report both (see `SOP-MAP-AND-CLAIMS.md`).
7. **The "OSCORE" framing is OSCORE-style** (pre-shared key, AES-CCM per 1 KiB block, 13 B nonce, 16 B tag), not RFC 8613. Replayed and reordered authentic blocks pass the per-block check and are caught only by the final image digest.
8. **Do not open the CSV files in Excel and save them.** Excel rewrites True/False as TRUE/FALSE and can reformat numbers. Open read-only or copy first; `data/MANIFEST.sha256` lets you check nothing changed.
9. **Never edit generated files by hand** (`STATISTICS.md`, `data/`, `figures/`): rerun the command.
10. **Success-Run (Eq. 6) bounds reliability, it does not prove security.** 60 of 60 gives at least 95% reliability at 95.39% confidence.

## 5. Folder contents

| Path | What it is |
|---|---|
| `TABLES-1-AND-4.md`, `TABLES-2-AND-3.md` | The approved tables, filled, with file hashes and provenance |
| `STATISTICS.md` | *Generated*: all tests, with the formula used |
| `data/ab_pairs.csv` | The 60 matched A/B pairs, one row per pair, A_ and B_ columns for every metric |
| `data/failures.csv` | The 9 failed counted cycles with the device's own cause |
| `data/table3_cycles.csv` | The 60 counted Table 3 cycles (all raw columns) |
| `data/scenarios_cde_trials.csv` | The 180 trials of Scenarios C, D, E |
| `data/MANIFEST.sha256` | SHA-256 of every generated file (check integrity) |
| `figures/` | `fig1_payload.png`, `fig2_time_to_completion.png`, `fig3_completion_time_spread.png`, `fig4_time_vs_repeated_requests.png`, `fig5_ledger_check_and_ram.png` |
| `scenarios-C-D-E/` | The Scenario C, D, E run: `campaign/trials.csv`, gateway logs, chain transaction logs, working files |

The raw runs sit next to this folder in `sop-results/`:

| Run folder | What it is | Table |
|---|---|---|
| `campaign-AB-full-20261019T025653Z/` | Scenarios A and B: `campaign/trials.csv` (all attempts), per-cycle serial logs and Wireshark captures in `raw/` | 2 |
| `campaign-T3-full-20261019T080000Z/` | Table 3 run: `campaign/table3.csv`, `table3.before-cycle6-rerun.csv` | 3 |
| `pilot-AB-...`, `pilot-T3-...` | The 5-cycle pilots (not analysed) | |
| `sop4-supporting-data/` | SOP 4 supporting evidence | |

## 6. Regenerate (from the `gateway/` folder of the repository)

```
S=../sop-results
python -m sop.chapter4 --ab $S/campaign-AB-full-20261019T025653Z --t3 $S/campaign-T3-full-20261019T080000Z \
    --cde $S/experiment-paper-tables/scenarios-C-D-E/campaign/trials.csv --web3 $S/sop4-supporting-data/on-device-web3 \
    --out $S/experiment-paper-tables --sop4 $S/sop4-supporting-data --tables --draft $S/CHAPTERS-4-AND-5-DRAFT.md
python -m sop.figures  (same --ab --t3 --cde --web3, plus --out $S/experiment-paper-tables)    # needs matplotlib
```

`--tables` rewrites `TABLES-1-AND-4.md` and `TABLES-2-AND-3.md` (the approved cells are produced by `gateway/sop/thesis_tables.py`); `--draft` refreshes only the Appendix of the chapter draft.

```
```

How each run was produced (not needed to read the data):

| Data | Command | Code |
|---|---|---|
| Scenarios C, D, E | `python -m sop.host_scenarios --trials 60 --run <folder>` | `gateway/sop/host_scenarios.py` |
| Scenarios A and B (ESP32 + PC gateway) | `python -m sop.device_cycle --serial COM3 --lan-ip <PC> --iface <n> --scenarios A,B --trials 60 --warmup 3 --static-ram-bytes 29416` | `gateway/sop/device_cycle.py` |
| Table 3 (Raspberry Pi) | `python -m sop.device_cycle --table3 --gateway-url http://<pi>:8000 --lan-ip <PC> --trials 60 --warmup 3` | `gateway/sop/device_cycle.py` |
| SOP 4 on-device Web3 | `python -m sop.web3_hw --serial COM3 --lan-ip <PC> --runs 60 --allow-flash` | `gateway/sop/web3_hw.py` |

The statistical functions are in `gateway/sop/inference.py` (Equations 1 to 6 and the supporting tests) and are covered by unit tests
(`python -m unittest discover -s sop/tests -t .` from `gateway/`). The approved table renderers are in `gateway/sop/thesis_tables.py`.
`trials.csv` hashes are recorded in `TABLES-1-AND-4.md`, `TABLES-2-AND-3.md` and `STATISTICS.md`.
