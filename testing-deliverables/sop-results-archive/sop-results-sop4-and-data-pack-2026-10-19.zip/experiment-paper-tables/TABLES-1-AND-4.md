# Experiment Paper tables: Table 1 (Instrument 1) and Table 4 (Instrument 4)

Generated from recorded data (`python -m sop.chapter4 --tables`). The table headings, columns and markers are the **approved** ones; only the cells are filled.
Tables 2 and 3 are in `TABLES-2-AND-3.md`. Statistics behind these tables: `STATISTICS.md`. How to use them in Chapters 4 and 5: `SOP-MAP-AND-CLAIMS.md`.

| Table | Serves | Equation | Draft section |
|---|---|---|---|
| 1 | SOP 1 (payload) | Eq. 3 (relative payload reduction) | 4.3.1 |
| 4 | SOP 3 (deterministic reliability) | Eq. 6 (Success-Run Theorem) | 4.5 |

---

**Table 1. Static Analysis of Volumetric Payload Optimization and Compression Ratio**

| Metric ID | Firmware Full Binary Version Pair Size (Bytes) | Delta Patch Size (Bytes) | Total Bytes Saved | Compression Ratio (%) |
|---|---|---|---|---|
| VOL_01 | v1.0 to v1.1: 288,880 | 22,497 | 266,383 | 92.21 |

**How to read it.** One static benchmark of the version pair, as the approved volume states (1 per version pair). "Firmware Full Binary" is the raw v1.1 image;
"Delta Patch" is the bsdiff4 engine output (BSDIFF40), not the device stream. Total Bytes Saved = 288,880 - 22,497 = 266,383.
Compression Ratio = 266,383 / 288,880 x 100 = **92.21%** (Equation 3 with the full image as the baseline).
The bytes on the wire measured in Scenarios A and B (86.13% fewer) are reported with Table 2, not here.

| Input | Path and size | SHA-256 |
|---|---|---|
| Base image (v1.0) | `C:\Users\jajai\Documents\PlatformIO\Projects\Thesis\release-images\app-v1.0.bin` (279,328 B) | `290dde7817ffe61d1c5ed4153c116c36d9fac8dd56342a6377a896bef33cc5fd` |
| Target image (v1.1) | `C:\Users\jajai\Documents\PlatformIO\Projects\Thesis\release-images\app-v1.1.bin` (288,880 B) | `60173d7cbd02038138350fa059175508753fd10d2cb80a0b5d030e9b97a5a1c8` |
| bsdiff4 patch | 22,497 B (bsdiff4 1.2.6) | `06763cc241bd60139e2c5085124350b28aeee5fb1d67a35fdbd284ffa65064b4` |

---

**Table 4. Deterministic Security Logic Validation and Success-Run Theorem Results**

| Cycle # | Scenario C: Tampered Patch (Rejected: Y/N) | Scenario D: Kill-Switch Revocation (Blocked: Y/N) | Scenario E: Incomplete Signature (Reverted: Y/N) | Success-Run Status |
|---|---|---|---|---|
| 1 | Pass | Pass | Pass | Valid |
| 2 | Pass | Pass | Pass | Valid |
| 3 | Pass | Pass | Pass | Valid |
| 4 | Pass | Pass | Pass | Valid |
| 5 | Pass | Pass | Pass | Valid |
| 6 | Pass | Pass | Pass | Valid |
| 7 | Pass | Pass | Pass | Valid |
| 8 | Pass | Pass | Pass | Valid |
| 9 | Pass | Pass | Pass | Valid |
| 10 | Pass | Pass | Pass | Valid |
| 11 | Pass | Pass | Pass | Valid |
| 12 | Pass | Pass | Pass | Valid |
| 13 | Pass | Pass | Pass | Valid |
| 14 | Pass | Pass | Pass | Valid |
| 15 | Pass | Pass | Pass | Valid |
| 16 | Pass | Pass | Pass | Valid |
| 17 | Pass | Pass | Pass | Valid |
| 18 | Pass | Pass | Pass | Valid |
| 19 | Pass | Pass | Pass | Valid |
| 20 | Pass | Pass | Pass | Valid |
| 21 | Pass | Pass | Pass | Valid |
| 22 | Pass | Pass | Pass | Valid |
| 23 | Pass | Pass | Pass | Valid |
| 24 | Pass | Pass | Pass | Valid |
| 25 | Pass | Pass | Pass | Valid |
| 26 | Pass | Pass | Pass | Valid |
| 27 | Pass | Pass | Pass | Valid |
| 28 | Pass | Pass | Pass | Valid |
| 29 | Pass | Pass | Pass | Valid |
| 30 | Pass | Pass | Pass | Valid |
| 31 | Pass | Pass | Pass | Valid |
| 32 | Pass | Pass | Pass | Valid |
| 33 | Pass | Pass | Pass | Valid |
| 34 | Pass | Pass | Pass | Valid |
| 35 | Pass | Pass | Pass | Valid |
| 36 | Pass | Pass | Pass | Valid |
| 37 | Pass | Pass | Pass | Valid |
| 38 | Pass | Pass | Pass | Valid |
| 39 | Pass | Pass | Pass | Valid |
| 40 | Pass | Pass | Pass | Valid |
| 41 | Pass | Pass | Pass | Valid |
| 42 | Pass | Pass | Pass | Valid |
| 43 | Pass | Pass | Pass | Valid |
| 44 | Pass | Pass | Pass | Valid |
| 45 | Pass | Pass | Pass | Valid |
| 46 | Pass | Pass | Pass | Valid |
| 47 | Pass | Pass | Pass | Valid |
| 48 | Pass | Pass | Pass | Valid |
| 49 | Pass | Pass | Pass | Valid |
| 50 | Pass | Pass | Pass | Valid |
| 51 | Pass | Pass | Pass | Valid |
| 52 | Pass | Pass | Pass | Valid |
| 53 | Pass | Pass | Pass | Valid |
| 54 | Pass | Pass | Pass | Valid |
| 55 | Pass | Pass | Pass | Valid |
| 56 | Pass | Pass | Pass | Valid |
| 57 | Pass | Pass | Pass | Valid |
| 58 | Pass | Pass | Pass | Valid |
| 59 | Pass | Pass | Pass | Valid |
| 60 | Pass | Pass | Pass | Valid |
| RESULT | Total Failures 0 | Total Failures 0 | Total Failures 0 | 95.4% Confidence Achieved |

**How to read it.** 60 automated cycles per scenario on a local Hardhat chain with the real gateway process (`sop/host_scenarios.py`). **Pass** means the attempt was
rejected, blocked or reverted as required:

| Scenario | What is attempted | Pass when |
|---|---|---|
| C: Tampered Patch | one bit of the patch is altered | the gateway detects the hash mismatch and stages nothing |
| D: Kill-Switch Revocation | a release is revoked on the smart contract | the gateway refuses the version request and holds no blocks |
| E: Incomplete Signature | a release below the 2-of-3 threshold is submitted | it never goes live; the extra signatures are reverted |

Success-Run (Equation 6): C = 1 - 0.95^60 = **95.39%**, valid only with zero failures in all three scenarios; it bounds reliability (at least 95% at this confidence),
it does not prove the failure probability is zero. 59 failure-free cycles are the minimum for 95% reliability at 95% confidence (1 - 0.95^59 = 95.15%).

| Item | Value |
|---|---|
| Run folder | `sop-results/experiment-paper-tables/scenarios-C-D-E/` |
| Per-trial data | `scenarios-C-D-E/campaign/trials.csv` (180 rows: C 60, D 60, E 60; 0 invalid) |
| `trials.csv` SHA-256 | `14319a9a028bac842c415eb9e23b23f5d50723cf53cb8ec8a7776d16c99794f5` |
| Gateway system logs | `scenarios-C-D-E/raw/campaign-c-gateway.log`, `campaign-d-gateway.log`, `campaign-e-gateway.log` |
| Blockchain transaction logs | `scenarios-C-D-E/raw/campaign-c-node.log`, `campaign-d-node.log`, `campaign-e-node.log` |
| Software revision | run recorded `87bfdf1`; tables rendered at `434f253` |
| Patch used in C, D and E | the real v1.0 to v1.1 patch above, SHA-256 `06763cc241bd6013...` |
| Do not | save `trials.csv` from a spreadsheet program: it rewrites the boolean spelling (the analysis tolerates it, but keep the original) |

Supplementary columns of the same run (not part of Table 4, used in the discussion): Scenario C detection time and Scenario D revocation propagation delay
(`STATISTICS.md`, section 8).
