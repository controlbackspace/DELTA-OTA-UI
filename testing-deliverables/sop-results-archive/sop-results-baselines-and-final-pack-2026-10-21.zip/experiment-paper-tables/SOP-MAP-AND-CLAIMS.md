# SOP map and claims sheet

For writing Chapters 4 and 5. Each SOP lists the instrument, the formula, the headline result, where it is in the draft (`../CHAPTERS-4-AND-5-DRAFT.md`), and what the data **allow** and **do not allow** us to say.
All numbers are generated in `STATISTICS.md`; table cells are in `TABLES-1-AND-4.md` and `TABLES-2-AND-3.md`.

## A. SOP by SOP

### SOP 1: payload optimisation by binary differencing
- **Question:** the measurable impact of binary differencing on payload footprint and bandwidth saturation.
- **Instrument / formula:** Table 1 (static) and the wire-byte and block columns of the A/B data; Equation 3.
- **Result:** patch 22,497 B against image 288,880 B, 266,383 B saved, **92.21%**. On the wire: 27,499 B against 198,211 B, **86.13%** fewer (paired t = -50.20, p = 4.2e-50, dz = -6.48, A fewer in 60 of 60). Blocks: 24 against 168 (**85.71%**).
- **Draft:** Section 4.3. **Figure:** `fig1_payload.png`.
- **We can claim:** delta differencing removes 92.2% of the stored payload and 86.1% of the traffic for a minor patch (v1.0 to v1.1). The result is significant under every test we ran.
- **We cannot claim:** that every update shrinks this much. One firmware pair was tested; the SOP 1 evidence shows unrelated inputs (incompressible noise) give no reduction. B is the full image **deflated** (168 blocks); raw it would be 283 blocks. Airtime and fleet times in the draft are **modelled** lower bounds.
- **Against the standard approach (Chapter 3 Baseline A, Eq. 3):** the full image over HTTPS puts 307,411 B on the wire against 27,499 B for the delta: **91.05% fewer bytes** (measured, 60 downloads, `BASELINES.md`). H is a lower bound (no certificate validation, default TLS buffers).

### SOP 2: OSCORE-style framing against standard handshakes
- **Question:** memory and latency reduction of the OSCORE approach against standard cryptographic handshakes.
- **Instrument / formula:** per-block timings from the A/B serial logs, Table 3 (encapsulation), the SOP 2 evidence report; Eq. 1, 2.
- **Result:** on the ESP32 one 1 KiB block decrypts in 1,528.6 µs (SD 3.1); a whole delta update spends about 36.7 ms decrypting, 0.66% of its time to completion. Gateway encapsulation: 6.13 ms for 24 blocks. Framing overhead 29 B per block, **no handshake**; a TLS 1.2 handshake would add 1,021 B in 4 flights (3.7% of a delta update's bytes) and an assumed ~101 ms (1.8% of its time).
- **Draft:** Section 4.4.
- **We can claim:** the security cost per block is small, constant and predictable on the device, and there is no handshake state or traffic.
- **We cannot claim:** that we measured a TLS or DTLS stack on the ESP32. The TLS figures are host measurements and specification values (**modelled/literature**), not device measurements. The framing is **OSCORE-style**, not RFC 8613 (no key derivation, no sequence numbers or replay window, no binding of release and block position into the authenticated data).
- **Security tax measured (Chapter 3 Baseline B, Absolute Difference):** secured delta (A) minus the same delta over naked CoAP (N), 60 matched pairs: **+42.7 ms** of decryption + reconstruction (95% CI 33.9 to 51.6, p = 8e-14; 0.8% of the time), time to completion **+179 ms, not significant (p = 0.20)**, +1,628 B on the wire (CI 69 to 3,188; the framing arithmetic is 696 B), +1.07 KB static RAM, +16.9 KB flash. A TLS handshake still rests on host measurements.

### SOP 3: deterministic reliability of ledger-anchored authenticity and revocation
- **Question:** the deterministic reliability of ledger-anchored smart contracts for authenticity and absolute revocation.
- **Instrument / formula:** Table 4 (Scenarios C, D, E); Equation 6; the SOP 3 evidence report (27 of 27 contract tests, 270 of 270 injected faults stopped).
- **Result:** 60 of 60 in each scenario, **0 failures**; C = 1 - 0.95^60 = **95.39%**. Kill-switch delay (revocation sent to refusal) mean 2,785 ms, range 176 to 4,981 ms, bounded by the 5 s polling interval.
- **Draft:** Section 4.5.
- **We can claim:** in 180 of 180 trials a tampered patch was never staged, a revoked release was never served, and a release without 2-of-3 approvals never went live; the data support at least 95% reliability at 95.39% confidence.
- **We cannot claim:** absolute security or a zero failure probability (Eq. 6 is a bound). Replay and reorder of authentic blocks are accepted by the per-block check and stopped only by the image digest (60 of 60 in the evidence report). Revocation timing was measured on a local chain (no block-confirmation delay). Device-side rollback after revocation and rejection of tampered blocks on flash were not recorded as 60-cycle series.

### SOP 4: offloading Web3 logic to the Edge Gateway
- **Question:** efficiency of offloading Web3 logic to the gateway in preserving the device's memory envelope (SRAM) and processing cycles.
- **Instrument / formula:** Table 3 (gateway profile), the SOP 4 supporting data, heap peaks from the A/B logs; Eq. 1, 2, 4, 5.
- **Result:** gateway per release: polling 54.13 ms, SHA-256 0.230 ms, AES-CCM 6.13 ms, 80.9 MB, 30.4% CPU. On the ESP32, one on-device ledger check takes 1,414 ms and peaks at 52,000 B of heap. Like-for-like (updater against updater + on-device Web3): flash **-78.47%**, static RAM -9.94%, peak RAM **-58.00%** (84,644 B = 165% of the 50 KiB Class 2 budget against 35,548 B = 69%).
- **Draft:** Section 4.6. **Figure:** `fig5_ledger_check_and_ram.png`. **Data:** `../sop4-supporting-data/`.
- **We can claim:** offloading keeps the device inside the Class 2 envelope; doing the Web3 work on the device does not (the minimal client alone needs 108% of the RAM budget once its heap is counted).
- **We cannot claim:** that the updater has less static RAM than a minimal read-only Web3 client taken alone (it has more: 29,400 B against 3,244 B, because it also reconstructs firmware). We cannot claim a RAM reduction of delta over full binary (static RAM identical; heap difference not significant, p = 0.158). The on-device client is a lower bound (read-only, no certificate validation, default TLS buffers, local TLS endpoint). The gateway and device ledger-check times are not exactly comparable (HTTP against TLS).
- **Against an HTTPS client (Eq. 4):** peak RAM (static + heap) is **71,668 B = 140%** of 50 KiB for HTTPS, against 35,534 B (69%, A's mean heap) to 46,072 B (90%, A's maximum): **50.4% to 35.7% less**. Flash: 72.3% less. Static RAM alone is higher for A (29.4 KB against 6.3 KB, the delta decoder). Say "exceeds / fits the Class 2 budget", never "runs / does not run on a Class 2 device" (the board has 520 KB).

### SOP 5: systemic performance over 60 automated cycles
- **Question:** performance of the complete architecture across cryptographic time, memory and CoAP latency over multi-cycle testing.
- **Instrument / formula:** Tables 2 and 3; Eq. 1, 2, 5; paired t-test.
- **Result:** time to completion **5,571.1 ms against 37,051.8 ms (-84.96%)**, t = -29.49, p = 5.2e-37, A faster in 60 of 60 pairs, 99%/95% limits 9.0 s against 60.5 s. Decryption + reconstruction 1,753.9 ms (SD 16.3). Flash write 184.3 against 195.9 KB/s (A **5.9% lower**). Static RAM 28.73 KB (SD 0). Spread of completion time explained by repeated block requests (r = 0.999; cycles with none: SD 38 ms).
- **Draft:** Section 4.7. **Figures:** `fig2`, `fig3`, `fig4`.
- **We can claim:** delta cuts update time by about 85% on this test bed and the result is robust (paired t, sign test, with and without cycles after a failure, unpaired). Device-side work is very stable (CV below 1%); variability comes from the Wi-Fi link.
- **We cannot claim:** that delta is faster on the device's flash path (throughput is 5.9% lower; the decoder takes 136 ms longer and decryption 227 ms less, net 91 ms faster), that the system is free of failures (9 of 138 counted attempts failed, 6.5%, cause unresolved), or generality beyond one device, one firmware pair and one Wi-Fi network. Energy was not measured.
- **Time against HTTPS: the delta is slower.** H completes in 3,733 ms (SD 405) against 5,571 ms for A (A is 49% longer; Welch p = 5e-17). It comes from the block protocol's 200 ms request pause, a tunable design parameter (Chapter 5). Report it plainly.
- **Failures: a test-harness race, not the architecture.** The updater starts updating by itself once the release is staged; the old harness then pulsed the reset pin, which interrupted the ota_0 -> ota_1 backup copy so the delta had no base. **0 of 182 cleanly started delta cycles failed**; a corrected harness had 0 failures in 40 confirmation cycles. Three B failures (2 bad headers, 1 stall) remain unexplained.

## B. Chapter 3 is fixed: how to present each difference in Chapter 4 (Chapter 3 is not edited)

Chapter 3 and the approved Experiment Paper stay as they are. Chapter 4 explains how the plan was carried out, in its own section (draft Section 4.1.3, "How the plan was carried out"), and the limitations list what was not done.
Rule of thumb: **where Chapter 3 contradicts itself, follow the part the approved Experiment Paper follows, and say so.**

### B1. Not deviations: Chapter 3 itself says the same (cite it)
| Topic | Where Chapter 3 / the approved paper says it | What to write in Chapter 4 |
|---|---|---|
| The comparison is delta against full binary through the same pipeline | Chapter 3, *Test Scenarios*: "Scenario B ... acting as the internal control benchmark ... the same v1.0 to v1.1 update without the delta patching algorithm"; *Research Design* and *Data Analysis* compare against "Full-OTA"; Experiment Paper, Instrument 2: "isolates the architectural efficiency against the Internal Control" | "Scenario B, the internal control defined in Chapter 3, is the comparison." The Equation 3 and 4 passage that names a standard-HTTPS "Baseline A" and a naked-CoAP "Baseline B" refers to scenarios that are not among the five scenarios of Chapter 3; the five scenarios and the approved Experiment Paper govern. |
| Wireshark | Experiment Paper: "Wireshark (Time-to-Completion)" | The capture used tshark, Wireshark's command-line tool, on the gateway PC |
| Gateway RAM and CPU tool | Experiment Paper, Table 3: Python psutil (Chapter 3 text names `memory_profiler`) | psutil, as in the approved Table 3 |

### B2. Operational choices: disclose in Section 4.1.3 with a reason and the effect
| # | Plan | What was done | Reason and effect |
|---|---|---|---|
| 1 | ESP32 peak RAM by `uxTaskGetStackHighWaterMark()` | **Static RAM** of the technology (updater image minus the Wi-Fi-only control) in Table 2, and the heap high-water mark from the device's `[MEM]` markers | A stack mark measures only the stack. Static RAM is the part that transfers to a Class 2 device, and heap covers dynamic use. Effect: the Table 2 RAM column is a build property (SD 0). |
| 2 | Pretest-posttest on the same hardware | A and B **interleaved** per round in random order (seeded), 3 warm-up rounds, paired by trial | Slow drift of the Wi-Fi channel hits both alike. |
| 3 | 60 trials per scenario | **60 complete pairs** analysed; 69 attempts per scenario | 9 counted cycles failed and a failed cycle has no completion time; trials were added (same seed) until 60 pairs were complete. The failed cycles are reported. |
| 4 | Gateway on a Raspberry Pi | Scenarios A and B: the **development PC** as gateway; Table 3: a Raspberry Pi 4 **capped to Pi 3B+ specifications** | The device-side and wire-side metrics do not depend on the gateway computer; the gateway cost (Table 3) was measured on the capped Pi. |
| 5 | OSCORE (RFC 8613) | **OSCORE-style** AEAD framing (pre-shared key, AES-CCM per block) | State the differences (no key derivation, no sequence numbers or replay window, no binding of release and block position into the authenticated data). |
| 6 | "Reconstruction throughput" first byte to reboot | Flash write throughput (bytes over time in `esp_ota_begin` + `esp_ota_write`); decryption + reconstruction = AES-CCM time + decoder time, from `[Metrics2]` | State the definitions (they are under Table 2 in `TABLES-2-AND-3.md`). |
| 7 | Update integrity rate | Success of updates: 93.5% (129 of 138 attempts); all 9 failures were detected by the device and none installed an image | Report with its interval (Wilson 88.1% to 96.5%). |

### B3. Not done: limitations and future work (do not hide, do not apologise)
| Plan | Status | How to handle |
|---|---|---|
| Naked CoAP and standard HTTPS baselines | **Measured** (supplementary, `BASELINES.md`) | H (HTTPS full binary) for Eq. 3 and 4 and N (naked CoAP delta) for the Absolute Difference, on the same board; the approved tables are unchanged. See `BASELINES-SPEC.md`. Caveats: H is a lower bound (no certificate validation) and unpaired with A; the TLS/DTLS handshake on the device is still host-measured. |
| Energy in mA | Not measured | Limitation; say less radio-on time is expected from 86% fewer bytes, but give no energy figure |
| TLS/DTLS comparison on the device | Host and specification values only | Label it modelled/literature |

If a panel member insists on a naked-CoAP number, a supplementary run is possible (about 60 cycles, roughly 2.5 hours) and would go to the supplementary data, not into the approved tables. Keep it as a contingency.

## C. Quick claims checklist

**Safe to state (with the numbers in `STATISTICS.md`)**
- Patch 92.21% smaller; 86.13% fewer bytes on the wire; 85.71% fewer blocks.
- Time to completion 84.96% shorter, highly significant, in 60 of 60 pairs; 99%/95% worst case 9.0 s against 60.5 s.
- 180 of 180 security trials passed; Success-Run 95.39%.
- Offloading saves 78.5% of flash and 58% of peak RAM against a non-offloaded design, and 1.4 s per ledger check.
- The gateway's work per release is small (about 60 ms of security work; 81 MB; 30% CPU on 3B+ limits).

**Must be stated with its caveat**
- RAM: static RAM is a build property; delta against full binary shows no RAM difference.
- The flash write rate is 5.9% lower for delta; the net decrypt + reconstruct gain is 4.9%.
- The 6.5% failure rate of the main A/B campaign is a harness artifact (6 of 9 failures were interrupted updates); 0 of 182 cleanly started delta cycles failed; 3 B failures are unexplained.
- TLS/DTLS comparison is modelled (host and specifications), not measured on the device.
- The on-device Web3 client is a lower bound; its comparison with the gateway poll is HTTP against TLS.

**Do not state**
- "Zero failures" overall (3 B failures are unexplained) or "absolute security".
- "RAM reduction of delta over full binary".
- Any energy saving.
- Generalisation to other devices or firmware without a caveat.
