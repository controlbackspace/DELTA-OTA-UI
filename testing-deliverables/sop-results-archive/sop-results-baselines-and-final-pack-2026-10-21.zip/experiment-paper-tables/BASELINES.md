# Chapter 3 comparators on the same board: HTTPS full binary (H) and naked CoAP delta (N)

Generated from recorded data (`python -m sop.chapter4 --n <N campaign> --h <H run> --tables`). Specification: `BASELINES-SPEC.md`.
**Supplementary**: the approved Tables 1 to 4 are not changed. H and N exist because Chapter 3's statistical treatment names a standard HTTPS full-binary update
(Equations 3 and 4) and an unsecured naked CoAP transfer (the Absolute Difference). They share the setup of Scenarios A and B (same ESP32, Wi-Fi, gateway PC,
firmware pair, tshark and serial measurement) but are separate conditions, not one architecture.

**Supplementary Table S2. Continuous Metrics for the Chapter 3 Comparators (not an approved instrument)**

| Cycle # | Scenario Type | Wireshark TTC (ms) | ESP32 Peak Ram Allocation (KB, static) | Decryption + Reconstruction Time (ms) | Total Flash Write Throughput (KB/s) | Bytes on the wire | Peak heap (B) |
|---|---|---|---|---|---|---|---|
| 1 | A (Delta-OTA, paired with N) | 5299.6 | 28.73 | 1774.0 | 181.9 | 26106 | 4820 |
| 1 | N (Naked CoAP delta) | 5278.7 | 27.66 | 1706.6 | 185.5 | 25410 | 6140 |
| 2 | A (Delta-OTA, paired with N) | 6586.2 | 28.73 | 1786.7 | 180.4 | 32880 | 7060 |
| 2 | N (Naked CoAP delta) | 6037.8 | 27.66 | 1705.7 | 185.7 | 29806 | 6232 |
| 3 | A (Delta-OTA, paired with N) | 5510.3 | 28.73 | 1760.5 | 183.5 | 27235 | 6360 |
| 3 | N (Naked CoAP delta) | 5289.7 | 27.66 | 1712.2 | 184.9 | 25410 | 6280 |
| 4 | A (Delta-OTA, paired with N) | 5463.4 | 28.73 | 1773.1 | 181.8 | 26106 | 6400 |
| 4 | N (Naked CoAP delta) | 5295.3 | 27.66 | 1710.7 | 185.0 | 25410 | 7396 |
| 5 | A (Delta-OTA, paired with N) | 5309.2 | 28.73 | 1759.8 | 183.6 | 26106 | 6236 |
| 5 | N (Naked CoAP delta) | 5358.4 | 27.66 | 1736.7 | 181.9 | 25410 | 6280 |
| 6 | A (Delta-OTA, paired with N) | 5329.3 | 28.73 | 1800.0 | 178.8 | 26106 | 6360 |
| 6 | N (Naked CoAP delta) | 5319.3 | 27.66 | 1740.2 | 181.6 | 25410 | 5408 |
| 7 | A (Delta-OTA, paired with N) | 12917.3 | 28.73 | 1767.1 | 183.0 | 69007 | 26092 |
| 7 | N (Naked CoAP delta) | 5444.0 | 27.66 | 1765.5 | 178.6 | 25410 | 6280 |
| 8 | A (Delta-OTA, paired with N) | 5356.9 | 28.73 | 1812.9 | 177.4 | 26106 | 6360 |
| 8 | N (Naked CoAP delta) | 5367.6 | 27.66 | 1791.7 | 175.6 | 25410 | 4588 |
| 9 | A (Delta-OTA, paired with N) | 5366.4 | 28.73 | 1819.8 | 176.7 | 26106 | 4356 |
| 9 | N (Naked CoAP delta) | 5338.5 | 27.66 | 1765.4 | 178.7 | 25410 | 6280 |
| 10 | A (Delta-OTA, paired with N) | 5447.3 | 28.73 | 1824.5 | 176.2 | 26106 | 6340 |
| 10 | N (Naked CoAP delta) | 5326.5 | 27.66 | 1753.7 | 180.0 | 25410 | 6280 |
| 11 | A (Delta-OTA, paired with N) | 5344.3 | 28.73 | 1798.4 | 179.2 | 26106 | 6372 |
| 11 | N (Naked CoAP delta) | 5320.6 | 27.66 | 1747.2 | 180.6 | 25410 | 6236 |
| 12 | A (Delta-OTA, paired with N) | 5318.3 | 28.73 | 1775.3 | 181.8 | 26106 | 4012 |
| 12 | N (Naked CoAP delta) | 5318.6 | 27.66 | 1726.3 | 183.3 | 25410 | 6236 |
| 13 | A (Delta-OTA, paired with N) | 5309.2 | 28.73 | 1765.4 | 182.9 | 26106 | 7712 |
| 13 | N (Naked CoAP delta) | 5375.9 | 27.66 | 1734.9 | 182.2 | 25410 | 6236 |
| 14 | A (Delta-OTA, paired with N) | 5418.0 | 28.73 | 1771.2 | 182.2 | 26106 | 6360 |
| 14 | N (Naked CoAP delta) | 5290.3 | 27.66 | 1711.1 | 184.9 | 25410 | 6256 |
| 15 | A (Delta-OTA, paired with N) | 5302.8 | 28.73 | 1753.5 | 184.4 | 26106 | 4356 |
| 15 | N (Naked CoAP delta) | 5333.6 | 27.66 | 1745.6 | 180.8 | 25410 | 6280 |
| 16 | A (Delta-OTA, paired with N) | 5350.2 | 28.73 | 1826.4 | 175.9 | 26106 | 6336 |
| 16 | N (Naked CoAP delta) | 5311.3 | 27.66 | 1739.8 | 181.6 | 25410 | 6280 |
| 17 | A (Delta-OTA, paired with N) | 5509.4 | 28.73 | 1762.0 | 183.4 | 26106 | 4596 |
| 17 | N (Naked CoAP delta) | 5349.1 | 27.66 | 1773.6 | 177.7 | 25410 | 6236 |
| 18 | A (Delta-OTA, paired with N) | 5377.3 | 28.73 | 1831.5 | 175.4 | 26106 | 4548 |
| 18 | N (Naked CoAP delta) | 5332.7 | 27.66 | 1729.1 | 182.9 | 25410 | 4208 |
| 19 | A (Delta-OTA, paired with N) | 5543.6 | 28.73 | 1788.2 | 180.2 | 27235 | 6240 |
| 19 | N (Naked CoAP delta) | 5731.6 | 27.66 | 1746.6 | 180.9 | 26629 | 4676 |
| 20 | A (Delta-OTA, paired with N) | 5331.0 | 28.73 | 1802.0 | 178.8 | 26106 | 6316 |
| 20 | N (Naked CoAP delta) | 5319.5 | 27.66 | 1748.6 | 180.5 | 25410 | 6728 |
| 21 | A (Delta-OTA, paired with N) | 5346.5 | 28.73 | 1811.1 | 177.6 | 26106 | 4332 |
| 21 | N (Naked CoAP delta) | 5334.1 | 27.66 | 1756.2 | 179.7 | 25410 | 6236 |
| 22 | A (Delta-OTA, paired with N) | 5351.7 | 28.73 | 1779.2 | 181.3 | 26106 | 6340 |
| 22 | N (Naked CoAP delta) | 5313.8 | 27.66 | 1727.4 | 183.1 | 25410 | 6236 |
| 23 | A (Delta-OTA, paired with N) | 5339.2 | 28.73 | 1786.6 | 180.5 | 26106 | 4332 |
| 23 | N (Naked CoAP delta) | 5765.1 | 27.66 | 1783.9 | 176.5 | 27610 | 6236 |
| 24 | A (Delta-OTA, paired with N) | 5454.8 | 28.73 | 1841.4 | 174.3 | 26106 | 7508 |
| 24 | N (Naked CoAP delta) | 5321.0 | 27.66 | 1746.0 | 180.9 | 25410 | 6132 |
| 25 | A (Delta-OTA, paired with N) | 5397.1 | 28.73 | 1848.2 | 173.5 | 26106 | 6632 |
| 25 | N (Naked CoAP delta) | 5357.2 | 27.66 | 1783.2 | 176.6 | 25410 | 4332 |
| 26 | A (Delta-OTA, paired with N) | 5385.6 | 28.73 | 1851.7 | 173.2 | 26106 | 6728 |
| 26 | N (Naked CoAP delta) | 5349.6 | 27.66 | 1769.9 | 178.1 | 25410 | 6236 |
| 27 | A (Delta-OTA, paired with N) | 5750.9 | 28.73 | 1794.8 | 179.4 | 28362 | 7240 |
| 27 | N (Naked CoAP delta) | 5318.4 | 27.66 | 1741.5 | 181.3 | 25410 | 6236 |
| 28 | A (Delta-OTA, paired with N) | 5354.8 | 28.73 | 1796.8 | 179.3 | 26106 | 4332 |
| 28 | N (Naked CoAP delta) | 5756.1 | 27.66 | 1775.5 | 177.5 | 27608 | 6728 |
| 29 | A (Delta-OTA, paired with N) | 5293.2 | 28.73 | 1746.3 | 185.2 | 26106 | 6340 |
| 29 | N (Naked CoAP delta) | 5361.7 | 27.66 | 1783.5 | 176.7 | 25410 | 6728 |
| 30 | A (Delta-OTA, paired with N) | 5343.0 | 28.73 | 1820.9 | 176.6 | 26106 | 4332 |
| 30 | N (Naked CoAP delta) | 5294.3 | 27.66 | 1718.0 | 184.1 | 25410 | 4332 |
| 31 | A (Delta-OTA, paired with N) | 5327.3 | 28.73 | 1775.5 | 181.7 | 26106 | 6372 |
| 31 | N (Naked CoAP delta) | 5294.6 | 27.66 | 1718.9 | 184.0 | 25410 | 6236 |
| 32 | A (Delta-OTA, paired with N) | 5518.2 | 28.73 | 1793.9 | 179.6 | 27234 | 6240 |
| 32 | N (Naked CoAP delta) | 5329.7 | 27.66 | 1722.2 | 183.6 | 25410 | 6236 |
| 33 | A (Delta-OTA, paired with N) | 5339.4 | 28.73 | 1791.7 | 179.8 | 26106 | 4492 |
| 33 | N (Naked CoAP delta) | 5292.5 | 27.66 | 1718.3 | 184.0 | 25410 | 4596 |
| 34 | A (Delta-OTA, paired with N) | 5297.8 | 28.73 | 1754.1 | 184.3 | 26106 | 4124 |
| 34 | N (Naked CoAP delta) | 6785.4 | 27.66 | 1711.8 | 184.9 | 33103 | 12636 |
| 35 | A (Delta-OTA, paired with N) | 5300.7 | 28.73 | 1757.8 | 183.8 | 26106 | 6340 |
| 35 | N (Naked CoAP delta) | 5338.7 | 27.66 | 1766.3 | 178.5 | 25410 | 6140 |
| 36 | A (Delta-OTA, paired with N) | 5312.8 | 28.73 | 1764.9 | 182.9 | 26106 | 6244 |
| 36 | N (Naked CoAP delta) | 5364.7 | 27.66 | 1729.8 | 182.7 | 25410 | 6236 |
| 37 | A (Delta-OTA, paired with N) | 5322.1 | 28.73 | 1793.4 | 179.6 | 26106 | 6336 |
| 37 | N (Naked CoAP delta) | 5321.3 | 27.66 | 1738.9 | 181.6 | 25410 | 4160 |
| 38 | A (Delta-OTA, paired with N) | 5358.0 | 28.73 | 1777.5 | 181.6 | 26106 | 6336 |
| 38 | N (Naked CoAP delta) | 5303.9 | 27.66 | 1735.0 | 182.2 | 25410 | 4504 |
| 39 | A (Delta-OTA, paired with N) | 5367.7 | 28.73 | 1843.6 | 174.0 | 26106 | 4332 |
| 39 | N (Naked CoAP delta) | 5311.3 | 27.66 | 1726.5 | 183.1 | 25410 | 4332 |
| 40 | A (Delta-OTA, paired with N) | 5316.5 | 28.73 | 1760.2 | 183.6 | 26106 | 4332 |
| 40 | N (Naked CoAP delta) | 5419.1 | 27.66 | 1788.3 | 176.0 | 25410 | 6236 |
| 41 | A (Delta-OTA, paired with N) | 5321.1 | 28.73 | 1765.4 | 182.9 | 26106 | 4236 |
| 41 | N (Naked CoAP delta) | 5348.4 | 27.66 | 1728.6 | 182.8 | 25410 | 6236 |
| 42 | A (Delta-OTA, paired with N) | 5322.9 | 28.73 | 1770.8 | 182.2 | 26106 | 4820 |
| 42 | N (Naked CoAP delta) | 5318.4 | 27.66 | 1729.4 | 182.8 | 25410 | 6236 |
| 43 | A (Delta-OTA, paired with N) | 5511.5 | 28.73 | 1779.2 | 181.3 | 27235 | 4452 |
| 43 | N (Naked CoAP delta) | 5382.2 | 27.66 | 1774.9 | 177.5 | 25410 | 4464 |
| 44 | A (Delta-OTA, paired with N) | 5304.5 | 28.73 | 1772.0 | 182.1 | 26106 | 6348 |
| 44 | N (Naked CoAP delta) | 5327.1 | 27.66 | 1723.5 | 183.5 | 25410 | 3972 |
| 45 | A (Delta-OTA, paired with N) | 6261.7 | 28.73 | 1763.0 | 183.2 | 30618 | 6368 |
| 45 | N (Naked CoAP delta) | 5509.0 | 27.66 | 1707.1 | 185.5 | 26510 | 6236 |
| 46 | A (Delta-OTA, paired with N) | 8329.5 | 28.73 | 1786.9 | 180.4 | 42055 | 7128 |
| 46 | N (Naked CoAP delta) | 5331.3 | 27.66 | 1757.9 | 179.5 | 25410 | 4504 |
| 47 | A (Delta-OTA, paired with N) | 5323.7 | 28.73 | 1768.6 | 182.5 | 26106 | 6336 |
| 47 | N (Naked CoAP delta) | 5354.1 | 27.66 | 1779.0 | 177.0 | 25410 | 6216 |
| 48 | A (Delta-OTA, paired with N) | 5289.2 | 28.73 | 1738.1 | 186.3 | 26106 | 6336 |
| 48 | N (Naked CoAP delta) | 5293.5 | 27.66 | 1718.4 | 184.1 | 25410 | 6236 |
| 49 | A (Delta-OTA, paired with N) | 5338.5 | 28.73 | 1791.2 | 179.9 | 26106 | 6344 |
| 49 | N (Naked CoAP delta) | 5317.8 | 27.66 | 1744.9 | 181.0 | 25410 | 6236 |
| 50 | A (Delta-OTA, paired with N) | 5333.9 | 28.73 | 1778.6 | 181.3 | 26106 | 6592 |
| 50 | N (Naked CoAP delta) | 5299.9 | 27.66 | 1717.4 | 184.2 | 25410 | 6236 |
| 51 | A (Delta-OTA, paired with N) | 5313.5 | 28.73 | 1757.8 | 183.8 | 26106 | 6340 |
| 51 | N (Naked CoAP delta) | 5292.4 | 27.66 | 1716.5 | 184.3 | 25410 | 6728 |
| 52 | A (Delta-OTA, paired with N) | 5322.6 | 28.73 | 1772.8 | 182.0 | 26106 | 6340 |
| 52 | N (Naked CoAP delta) | 5346.0 | 27.66 | 1768.1 | 178.5 | 25410 | 4332 |
| 53 | A (Delta-OTA, paired with N) | 5346.1 | 28.73 | 1799.7 | 179.0 | 26106 | 6940 |
| 53 | N (Naked CoAP delta) | 5280.4 | 27.66 | 1707.2 | 185.4 | 25410 | 4852 |
| 54 | A (Delta-OTA, paired with N) | 5297.5 | 28.73 | 1745.1 | 185.3 | 26106 | 6728 |
| 54 | N (Naked CoAP delta) | 5345.2 | 27.66 | 1770.7 | 178.0 | 25410 | 4584 |
| 55 | A (Delta-OTA, paired with N) | 5304.4 | 28.73 | 1757.6 | 183.9 | 26106 | 6340 |
| 55 | N (Naked CoAP delta) | 5928.0 | 27.66 | 1751.3 | 180.1 | 28707 | 11356 |
| 56 | A (Delta-OTA, paired with N) | 5306.6 | 28.73 | 1757.7 | 183.8 | 26106 | 6336 |
| 56 | N (Naked CoAP delta) | 5306.2 | 27.66 | 1729.8 | 182.7 | 25410 | 6236 |
| 57 | A (Delta-OTA, paired with N) | 5357.8 | 28.73 | 1803.4 | 178.5 | 26106 | 6728 |
| 57 | N (Naked CoAP delta) | 5288.4 | 27.66 | 1709.1 | 185.2 | 25410 | 6236 |
| 58 | A (Delta-OTA, paired with N) | 5316.7 | 28.73 | 1760.7 | 183.4 | 26106 | 7216 |
| 58 | N (Naked CoAP delta) | 5329.3 | 27.66 | 1748.8 | 180.4 | 25410 | 6236 |
| 59 | A (Delta-OTA, paired with N) | 5493.3 | 28.73 | 1747.7 | 185.0 | 27234 | 6340 |
| 59 | N (Naked CoAP delta) | 5283.6 | 27.66 | 1710.1 | 185.2 | 25410 | 7360 |
| 60 | A (Delta-OTA, paired with N) | 5306.4 | 28.73 | 1757.1 | 183.8 | 26106 | 4332 |
| 60 | N (Naked CoAP delta) | 5302.5 | 27.66 | 1725.1 | 183.3 | 25410 | 3968 |
| 1 | H (HTTPS full binary) | 5641.1 | 6.18 | 2727.8 | 189.2 | 312479 | - |
| 2 | H (HTTPS full binary) | 5155.5 | 6.18 | 2355.4 | 192.4 | 306998 | - |
| 3 | H (HTTPS full binary) | 4620.0 | 6.18 | 1756.3 | 182.5 | 306614 | - |
| 4 | H (HTTPS full binary) | 3594.9 | 6.18 | 832.5 | 193.0 | 307200 | - |
| 5 | H (HTTPS full binary) | 3545.2 | 6.18 | 775.2 | 191.2 | 307360 | - |
| 6 | H (HTTPS full binary) | 3572.1 | 6.18 | 775.9 | 189.1 | 308055 | - |
| 7 | H (HTTPS full binary) | 3617.6 | 6.18 | 857.5 | 192.5 | 308258 | - |
| 8 | H (HTTPS full binary) | 3563.1 | 6.18 | 780.0 | 192.3 | 306998 | - |
| 9 | H (HTTPS full binary) | 3677.3 | 6.18 | 902.9 | 191.4 | 307520 | - |
| 10 | H (HTTPS full binary) | 4424.7 | 6.18 | 1621.3 | 189.4 | 311790 | - |
| 11 | H (HTTPS full binary) | 3543.9 | 6.18 | 756.4 | 190.7 | 307082 | - |
| 12 | H (HTTPS full binary) | 3930.8 | 6.18 | 1126.1 | 190.2 | 307310 | - |
| 13 | H (HTTPS full binary) | 3898.2 | 6.18 | 1144.0 | 200.4 | 307160 | - |
| 14 | H (HTTPS full binary) | 3772.8 | 6.18 | 983.1 | 191.5 | 307480 | - |
| 15 | H (HTTPS full binary) | 3615.5 | 6.18 | 839.9 | 190.7 | 307202 | - |
| 16 | H (HTTPS full binary) | 3695.0 | 6.18 | 783.7 | 180.7 | 306295 | - |
| 17 | H (HTTPS full binary) | 4155.5 | 6.18 | 1383.8 | 189.8 | 307238 | - |
| 18 | H (HTTPS full binary) | 3779.9 | 6.18 | 930.1 | 189.2 | 306414 | - |
| 19 | H (HTTPS full binary) | 3604.5 | 6.18 | 756.7 | 182.1 | 306962 | - |
| 20 | H (HTTPS full binary) | 3587.4 | 6.18 | 797.2 | 189.6 | 307078 | - |
| 21 | H (HTTPS full binary) | 3524.9 | 6.18 | 741.5 | 188.9 | 308874 | - |
| 22 | H (HTTPS full binary) | 3648.1 | 6.18 | 842.6 | 187.0 | 307202 | - |
| 23 | H (HTTPS full binary) | 3549.0 | 6.18 | 758.1 | 189.5 | 308598 | - |
| 24 | H (HTTPS full binary) | 3514.9 | 6.18 | 758.5 | 193.0 | 307042 | - |
| 25 | H (HTTPS full binary) | 3550.2 | 6.18 | 775.0 | 191.5 | 308670 | - |
| 26 | H (HTTPS full binary) | 3525.6 | 6.18 | 740.1 | 189.9 | 307162 | - |
| 27 | H (HTTPS full binary) | 3808.0 | 6.18 | 1030.0 | 192.8 | 307120 | - |
| 28 | H (HTTPS full binary) | 3872.3 | 6.18 | 1114.0 | 193.1 | 307202 | - |
| 29 | H (HTTPS full binary) | 3844.9 | 6.18 | 1109.4 | 198.9 | 306414 | - |
| 30 | H (HTTPS full binary) | 3526.8 | 6.18 | 749.0 | 190.8 | 306838 | - |
| 31 | H (HTTPS full binary) | 3513.0 | 6.18 | 765.3 | 195.4 | 306294 | - |
| 32 | H (HTTPS full binary) | 3565.6 | 6.18 | 727.8 | 184.8 | 307080 | - |
| 33 | H (HTTPS full binary) | 3515.3 | 6.18 | 747.6 | 191.6 | 306920 | - |
| 34 | H (HTTPS full binary) | 3525.2 | 6.18 | 731.8 | 190.8 | 306880 | - |
| 35 | H (HTTPS full binary) | 3629.0 | 6.18 | 795.7 | 183.2 | 307000 | - |
| 36 | H (HTTPS full binary) | 3680.3 | 6.18 | 905.3 | 190.3 | 306878 | - |
| 37 | H (HTTPS full binary) | 3502.6 | 6.18 | 724.2 | 189.5 | 306802 | - |
| 38 | H (HTTPS full binary) | 3661.8 | 6.18 | 858.3 | 187.0 | 307080 | - |
| 39 | H (HTTPS full binary) | 3546.1 | 6.18 | 763.6 | 189.8 | 306960 | - |
| 40 | H (HTTPS full binary) | 3546.3 | 6.18 | 776.2 | 190.9 | 308585 | - |
| 41 | H (HTTPS full binary) | 3580.7 | 6.18 | 777.6 | 187.4 | 307280 | - |
| 42 | H (HTTPS full binary) | 3654.1 | 6.18 | 867.1 | 190.2 | 307318 | - |
| 43 | H (HTTPS full binary) | 4828.2 | 6.18 | 1981.4 | 189.5 | 309527 | - |
| 44 | H (HTTPS full binary) | 3665.2 | 6.18 | 789.8 | 189.2 | 306215 | - |
| 45 | H (HTTPS full binary) | 3458.5 | 6.18 | 721.9 | 196.0 | 306958 | - |
| 46 | H (HTTPS full binary) | 3627.0 | 6.18 | 822.0 | 187.5 | 306998 | - |
| 47 | H (HTTPS full binary) | 3612.3 | 6.18 | 787.5 | 187.8 | 307188 | - |
| 48 | H (HTTPS full binary) | 3649.4 | 6.18 | 764.6 | 178.1 | 307238 | - |
| 49 | H (HTTPS full binary) | 3598.4 | 6.18 | 773.6 | 185.7 | 307080 | - |
| 50 | H (HTTPS full binary) | 3590.5 | 6.18 | 767.1 | 186.1 | 308594 | - |
| 51 | H (HTTPS full binary) | 3595.7 | 6.18 | 771.9 | 184.9 | 307040 | - |
| 52 | H (HTTPS full binary) | 3539.8 | 6.18 | 759.0 | 190.0 | 307040 | - |
| 53 | H (HTTPS full binary) | 3518.6 | 6.18 | 759.3 | 189.5 | 306960 | - |
| 54 | H (HTTPS full binary) | 3594.2 | 6.18 | 783.5 | 187.3 | 306215 | - |
| 55 | H (HTTPS full binary) | 3547.3 | 6.18 | 734.6 | 186.3 | 306958 | - |
| 56 | H (HTTPS full binary) | 3532.7 | 6.18 | 744.9 | 191.4 | 308394 | - |
| 57 | H (HTTPS full binary) | 3584.4 | 6.18 | 789.1 | 191.5 | 307000 | - |
| 58 | H (HTTPS full binary) | 3702.9 | 6.18 | 918.1 | 190.0 | 306762 | - |
| 59 | H (HTTPS full binary) | 3523.4 | 6.18 | 740.0 | 190.2 | 307735 | - |
| 60 | H (HTTPS full binary) | 3528.2 | 6.18 | 776.2 | 193.4 | 307078 | - |
| STAT | Arithmetic Mean (A (Delta-OTA, paired with N)) | 5576.1 | 28.73 | 1783.6 | 180.8 | 27407 | 6218 |
| STAT | Arithmetic Mean (N (Naked CoAP delta)) | 5397.6 | 27.66 | 1740.8 | 181.5 | 25778 | 5996 |
| STAT | Arithmetic Mean (H (HTTPS full binary)) | 3732.9 | 6.18 | 935.5 | 189.6 | 307411 | - |
| STAT | Standard Deviation (A (Delta-OTA, paired with N)) | 1056.4 | 0.00 | 27.6 | 3.2 | 5925 | 2807 |
| STAT | Standard Deviation (N (Naked CoAP delta)) | 237.4 | 0.00 | 24.7 | 2.9 | 1260 | 1443 |
| STAT | Standard Deviation (H (HTTPS full binary)) | 404.9 | 0.00 | 390.6 | 3.8 | 1111 | - |
| FOOTER | H peak heap, highest of the downloads | - | - | - | - | - | 65,344 |

*Supplementary: the approved Tables 1 to 4 are unchanged. A is re-measured in the same rounds as N (paired); N is the naked-CoAP delta (Chapter 3 Baseline B); H is the full binary over HTTPS (Chapter 3 Baseline A), 60 downloads in one boot. For H the Decryption + Reconstruction cell is the receive-and-decrypt time (download time minus flash time), and the peak heap is one value for the series (the highest of the 60 downloads), shown in the footer row.*

## Chapter 3 comparators on the same board: HTTPS full binary (H) and naked CoAP delta (N)

Specification: `BASELINES-SPEC.md`. Both are supplementary: they are not part of the approved Tables 1 to 4.

### 1 N: the security tax (Absolute Difference, A minus N, paired)

60 complete A/N pairs. Counted attempts: A ok 64, failed 7; N ok 67, failed 4; harness faults re-run: A 12, N 10.

| Metric | A (secured) mean (SD) | N (naked) mean (SD) | A - N (95% CI) | t | p | dz |
|---|---|---|---|---|---|---|
| Wireshark TTC (ms) | 5,576.1 (1,056.4) | 5,397.6 (237.4) | 178.6 (-97.3 to 454.4) | 1.30 | 0.200 | 0.17 |
| Bytes on the wire | 27,407 (5,925) | 25,778 (1,260) | 1,628 (69 to 3,188) | 2.09 | 0.041 | 0.27 |
| Decryption + reconstruction (ms) | 1,783.6 (27.6) | 1,740.8 (24.7) | 42.7 (33.9 to 51.6) | 9.71 | 7.8e-14 | 1.25 |
| Flash write throughput (KB/s) | 180.8 (3.2) | 181.5 (2.9) | -0.7 (-1.7 to 0.4) | -1.29 | 0.201 | -0.17 |
| AES-CCM decryption per block (us) | 1,528.6 (3.5) | 0.0 (0.0) | 1,528.6 (1,527.7 to 1,529.5) | 3,369.39 | 1.3e-157 | 434.99 |
| Decoder time: inflate, merge, flash (us) | 1,746,885 (27,635) | 1,740,824 (24,733) | 6,061 (-2,754 to 14,876) | 1.38 | 0.174 | 0.18 |
| Peak heap used during the update (B) | 6,218 (2,807) | 5,996 (1,443) | 223 (-589 to 1,034) | 0.55 | 0.585 | 0.07 |
| Static RAM of the technology (KB) | 28.73 (0.00) | 27.66 (0.00) | 1.07 (no variance) | - | - | - |

Framing arithmetic: 29 B (13 B nonce + 16 B tag) x 24 blocks = 696 B expected per update; the measured difference also contains the effect of repeated block requests.

| Scenario | Harness interrupted the update: ok / failed | Clean start: ok / failed |
|---|---|---|
| A | 5 / 7 | 59 / 0 |
| N | 4 / 4 | 63 / 0 |

Security tax on all 60 pairs and on the 53 pairs in which neither cycle was interrupted by the old harness:

| Metric | A - N, all pairs (95% CI), p | A - N, clean pairs (95% CI), p |
|---|---|---|
| Wireshark TTC (ms) | 178.6 (-97.3 to 454.4), p = 0.200 | 188.8 (-124.0 to 501.5), p = 0.231 |
| Bytes on the wire | 1,628.2 (68.8 to 3,187.6), p = 0.041 | 1,706.5 (-62.7 to 3,475.6), p = 0.058 |
| Decryption + reconstruction (ms) | 42.7 (33.9 to 51.6), p = 7.8e-14 | 41.4 (31.7 to 51.2), p = 2.0e-11 |

### 2 H: HTTPS full binary (Equations 3 and 4)

60 counted downloads ok, 0 failed (one boot, 3 warm-up discarded). H against A is **unpaired** (H is a single-boot series).

| H column | Mean | SD | UTL (Eq. 5) | Min | Max |
|---|---|---|---|---|---|
| Time to completion (ms) | 3,732.9 | 404.9 | 4,869.6 | 3,458.5 | 5,641.1 |
| Bytes on the wire | 307,411 | 1,111 | 310,530 | 306,215 | 312,479 |
| TCP + TLS connect (ms) | 1,362.1 | 27.0 | 1,438.0 | 1,341.0 | 1,479.0 |
| Download incl. flash (ms) | 2,423.7 | 389.7 | 3,517.8 | 2,161.0 | 4,219.0 |
| Device total (ms) | 3,785.8 | 406.5 | 4,926.9 | 3,510.0 | 5,698.0 |
| Flash write throughput (KB/s) | 189.6 | 3.8 | 200.4 | 178.1 | 200.4 |

**Equation 3 (payload).** Static: (288,880 - 22,497) / 288,880 = **92.21%** (Table 1). On the wire: H 307,411 B against A 27,499 B = **91.05% fewer bytes** (Welch t = -311.5, p = 9.2e-101).

**Time to completion.** H 3,733 ms (SD 405) against A 5,571 ms (SD 1,230): A is 49.2% longer than H (Welch t = 11.0, p = 4.6e-17).

**Equation 4 (RAM) and flash.**

| | H (HTTPS) | A (proposed) | Reduction % (Eq. 4) |
|---|---|---|---|
| Static RAM added (B) | 6,324 | 29,416 | -365.1 (A is higher: it carries the delta decoder) |
| Peak heap (B): H series maximum, A at its mean / maximum | 65,344 | 6,118 / 16,656 | 90.6 / 74.5 |
| **Peak RAM, static + heap (B)** | 71,668 (140% of 50 KiB) | 35,534 (69%) mean; 46,072 (90%) max | **50.4** (A mean) / **35.7** (A max) |
| Flash added (B) | 156,548 (61.2% of 250 KiB) | 43,340 (16.9%) | 72.3 |

H is a lower bound: no certificate validation and the framework's default TLS buffers. The 50 KiB and 250 KiB figures are an accounting budget on a 520 KB ESP32, not a hardware limit: read the result as 'fits' or 'exceeds' the Class 2 budget.

Cross-check: the capture's time to completion minus the device's own time is -53 ms on average (SD 8), the device total including the final image verification.



## Provenance
- N campaign (A and N, interleaved): `C:\Users\jajai\Desktop\DELTA-OTA-UI\sop-results\baselines-N-full\campaign\trials.csv` (sha256 `866abb1009bef0983ecf9a7de71ffdb602162ed1a9923209cbad25556d33555d`)
- H run: `C:\Users\jajai\Desktop\DELTA-OTA-UI\sop-results\baselines-H-full\campaign\https_runs.csv` (sha256 `b8379b6c97968fa038ae7a8e688b0682178a01b285c45fdcad84f6f5f0be5289`), `summary.json`, `static_increments.json`
- Firmware: separate PlatformIO environments `https_baseline`, `https_control` and `factory_naked` of the firmware repository; the standard `factory` environment is unchanged in code (its image differs from the original in the 64 bytes derived from the ELF checksum only).
- Table code revision: b7b698a.
