# Experiment Paper tables: working folder

Local evidence for the approved Experiment Paper tables (Tables 1 to 4). This folder is inside `sop-results/`, which git ignores, so it stays on this PC.
The approved table layouts are not changed; only their cells are filled from recorded data.

| Path | What it is | Table |
|---|---|---|
| `TABLES-1-AND-4.md` | Table 1 (static payload analysis) and Table 4 (deterministic validation), with provenance and file hashes | 1, 4 |
| `scenarios-C-D-E/campaign/trials.csv` | One row per trial: 60 each of Scenarios C, D and E (180 rows) | 4 |
| `scenarios-C-D-E/campaign/TABLE-4.md` | Table 4 as first rendered from the run | 4 |
| `scenarios-C-D-E/raw/` | Gateway system logs and blockchain (Hardhat node) transaction logs per scenario | 4 |
| `scenarios-C-D-E/work_campaign_*/` | Working files of the run (the tampered patches of Scenario C, gateway status files) | 4 |

Tables 2 and 3 were added on 2026-10-19:

| Path | What it is | Table |
|---|---|---|
| `TABLES-2-AND-3.md` | Table 2 (Scenarios A and B, 60 complete pairs) and Table 3 (Raspberry Pi gateway, 60 cycles), with provenance and file hashes | 2, 3 |
| `../campaign-AB-full-20261019T025653Z/` | Scenario A and B campaign: `campaign/trials.csv`, per-cycle serial logs and captures | 2 |
| `../campaign-T3-full-20261019T080000Z/` | Table 3 run: `campaign/table3.csv` (and `table3.before-cycle6-rerun.csv`), gateway logs | 3 |

How the C, D, E data was produced: `python -m sop.host_scenarios --trials 60 --run <folder>` from `gateway/` (code: `gateway/sop/host_scenarios.py`).
Do not save `trials.csv` from a spreadsheet program: it rewrites the values; open it read-only or copy it first. Its SHA-256 is recorded in `TABLES-1-AND-4.md`.
