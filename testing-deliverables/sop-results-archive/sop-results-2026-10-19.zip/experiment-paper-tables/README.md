# Experiment Paper tables: working folder

Local evidence for the approved Experiment Paper tables (Tables 1 to 4). This folder is inside `sop-results/`, which git ignores, so it stays on this PC.
The approved table layouts are not changed; only their cells are filled from recorded data.

| Path | What it is | Table |
|---|---|---|
| `TABLES-1-AND-4.md` | Table 1 (static payload analysis) and Table 4 (deterministic validation), with provenance and file hashes | 1, 4 |
| `scenarios-C-D-E/campaign/trials.csv` | One row per trial: 60 each of Scenarios C, D and E (180 rows) | 4 |
| `scenarios-C-D-E/campaign/TABLE-4.md` | Table 4 as first rendered from the run | 4 |
| `scenarios-C-D-E/raw/` | Gateway system logs and blockchain (Hardhat node) transaction logs per scenario | 4 |
| `scenarios-C-D-E/work_campaign_*/` | Working files of the run (the tampered patches of Scenario C, gateway status files) | 4 |

Not here yet: Table 2 (Scenarios A and B, needs the ESP32) and Table 3 (gateway profiling, to be measured on the Raspberry Pi).

How the C, D, E data was produced: `python -m sop.host_scenarios --trials 60 --run <folder>` from `gateway/` (code: `gateway/sop/host_scenarios.py`).
Do not save `trials.csv` from a spreadsheet program: it rewrites the values; open it read-only or copy it first. Its SHA-256 is recorded in `TABLES-1-AND-4.md`.
