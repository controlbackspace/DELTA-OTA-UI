# Discarded attempts (no measurement)

These two folders are the first two tries of the on-device Web3 measurement on 2026-10-19. They hold **no usable data**: the board never ran the
Web3 baseline. They are kept so the history of the retries is visible.

| Folder | What happened |
|---|---|
| `D01_sop4_web3-board-booted-old-app_2026-10-19` | The baseline was written to the factory slot, but the board kept booting the demo application in `ota_0` (v1.1, left there by the Table 2 campaign). The serial log shows `Delta-OTA demo application v1.1 (running from ota_0)`, not the SOP4 banner. |
| `D02_sop4_web3-otadata-erased-too-early_2026-10-19` | Same result. Erasing `otadata` **before** the upload did not help, because `pio run -t upload` writes `boot_app0` again, which selects `ota_0`. |

Cause and fix: erase `otadata` (`0xd000`, size `0x2000`) **after** the upload, as `tools\flash_device.bat` does for the factory image. The third attempt did that and
produced the measurement in `../runs/R05_sop4_web3-client-on-device_2026-10-19/`. The fix is now part of `sop4.hw_session` (see `gateway/sop/sop4.py`).
