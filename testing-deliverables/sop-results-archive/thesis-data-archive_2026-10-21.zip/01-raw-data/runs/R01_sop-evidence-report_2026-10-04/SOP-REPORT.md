# Experimental Evidence Report

**Securing Delta-OTA for Constrained IoT via OSCORE and Ledger-Anchored Release Governance**

*Evidence for Statements of the Problem 1 to 4*

## 1. Purpose and Scope

This report presents the experimental evidence gathered for Statements of the Problem 1 to 4 of the study. Each result is classified by its basis: **Measured** (observed on the stated system), **Modelled** (computed from stated assumptions) or **Literature** (values taken from the cited specifications). Statement 5 (multi-cycle systemic performance) is reserved for the implementation phase and is described in Section 3.5.

## 2. Experimental Setup

- **Date (UTC):** 2026-10-04 00:41:35
- **Software revision:** `1b11f3c`
- **Host:** Windows-11-10.0.26300-SP0; 16 logical CPUs; Python 3.12.8
- **Libraries:** bsdiff4 1.2.6, cryptography 50.0.0, aiocoap 0.4.17, web3 7.16.0, pyserial 3.5
- **Framing under evaluation:** OSCORE-style AEAD framing (`emulated`)
- **Input, real firmware base:** `C:\Users\jajai\Documents\PlatformIO\Projects\Thesis\release-images\app-v1.0.bin` (279,328 bytes; SHA-256 `290dde7817ffe61d1c5ed4153c116c36d9fac8dd56342a6377a896bef33cc5fd`)
- **Input, real firmware target:** `C:\Users\jajai\Documents\PlatformIO\Projects\Thesis\release-images\app-v1.1.bin` (288,880 bytes; SHA-256 `60173d7cbd02038138350fa059175508753fd10d2cb80a0b5d030e9b97a5a1c8`)
- **Input, fixture base:** `C:\Users\jajai\Desktop\DELTA-OTA-UI\gateway\fixtures\v1.0.bin` (100,000 bytes; SHA-256 `6d1cf22d7cc09b085dfc25ee1a1f3ae0265804c607bc2074ad253bcc82fd81ee`)
- **Input, fixture target:** `C:\Users\jajai\Desktop\DELTA-OTA-UI\gateway\fixtures\v1.1.bin` (100,001 bytes; SHA-256 `3ce10647828a0c12474300948edf5cef34e42a4cde2ee5a805fd80abc8684f8b`)

**Table 1.** Software environment of the evaluation host *(Measured)*

| Component | Status | Detail |
|---|---|---|
| Python | Available | 3.12.8 |
| bsdiff4 | Available | importable |
| Real firmware pair | Available | C:\Users\jajai\Documents\PlatformIO\Projects\Thesis\release-images\app-v1.0.bin -> C:\Users\jajai\Documents\PlatformIO\Projects\Thesis\release-images\app-v1.1.bin |
| git | Available | run metadata |
| npx | Available | SOP3 contract tests and chain |
| pio (PlatformIO) | Available | C:\Users\jajai\.platformio\penv\Scripts\pio.exe |
| Firmware project | Available | C:\Users\jajai\Documents\PlatformIO\Projects\Thesis |
| pyserial | Available | hardware steps available |

## 3. Results

### 3.1 Statement of the Problem 1

**Research question.** What is the measurable impact of binary volumetric differencing on optimizing the firmware payload footprint and mitigating network bandwidth saturation for constrained Class 2 microcontrollers?

**Method.** Update artifacts were generated with the production release builder (bsdiff4, producing a BSDIFF40 patch) and re-packed into the device stream format (DOTA). Payload sizes, block counts and generation times were measured for the real firmware pair, a 100 KB test pair and six synthetic stress cases. Bytes on the wire were derived from the exact frame layout of the update protocol (CoAP request and reply, AEAD framing and UDP/IP headers for every block). Each reconstruction was verified byte for byte. Airtime and fleet-update durations were modelled from stated link rates.

**Principal result.** For app-v1.0.bin -> app-v1.1.bin, the update is delivered in 24 blocks instead of 158 for a full image, 85.3% less traffic on the wire.

**Findings.**

1. For the pair app-v1.0.bin -> app-v1.1.bin, the new image is 288,880 B. The BSDIFF40 patch is 22,497 B and the device stream (DOTA) is 23,614 B (91.8% smaller than the image). It is delivered in 24 blocks, compared with 158 blocks for the same image sent as a full deflated image and 283 blocks sent raw. On the wire (CoAP, AEAD framing and UDP/IP) this is 26,124 B against 178,076 B (85.3% less) for the full deflated image and 318,768 B (91.8% less) for the raw image. *(Measured; production firmware.)*
2. Updating 100 devices one after another on a shared 802.15.4 (250 kbit/s) channel would take 1.4 min with the delta versus 9.5 min with a full (DOTA) image and 17.0 min with a raw image. *(Modelled; lower bound.)*

**Table 2.** Payload and block counts per firmware pair *(Measured)*

| Case | Kind | New image (B) | BSDIFF40 (B) | DOTA delta (B) | DOTA vs image | Blocks: delta | Blocks: full (DOTA) | Blocks: full (raw) | Wire saved vs full (DOTA) | Wire saved vs full (raw) | Round-trip OK | bsdiff time |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| app-v1.0.bin -> app-v1.1.bin | real | 288,880 | 22,497 | 23,614 | 91.8% | 24 | 158 | 283 | 85.3% | 91.8% | yes | 33.1 ± 0.4 ms (n=5) |
| fixtures v1.0 -> v1.1 | fixture | 100,001 | 164 | 144 | 99.9% | 1 | 1 | 98 | -2.1% | 99.8% | yes | 161.8 ± 1.3 ms (n=5) |
| dummy-4B | synthetic | 4 | 127 | 27 | -575.0% | 1 | 1 | 1 | 1.5% | -21.3% | yes | 0.1 ± 0.0 ms (n=5) |
| image-3KB | synthetic | 3,001 | 164 | 48 | 98.4% | 1 | 1 | 3 | 13.6% | 95.4% | yes | 0.3 ± 0.0 ms (n=5) |
| synth-1.2MB | synthetic | 1,200,000 | 149 | 4,117 | 99.7% | 5 | 11 | 1172 | 59.6% | 99.6% | yes | 208.5 ± 12.2 ms (n=3) |
| identical-3KB | synthetic | 3,000 | 140 | 46 | 98.5% | 1 | 1 | 3 | 14.3% | 95.5% | yes | 0.3 ± 0.0 ms (n=5) |
| noise-64KB | synthetic | 65,536 | 66,285 | 65,584 | -0.1% | 65 | 65 | 64 | 0.0% | -0.2% | yes | 18.5 ± 0.1 ms (n=5) |
| fw-bump-1.25MB | synthetic | 1,310,720 | 209 | 1,804 | 99.9% | 2 | 19 | 1280 | 90.3% | 99.9% | yes | 295.6 ± 39.0 ms (n=3) |

*Sizes, block counts and times were measured with the production code (5 timing repeats; 1024-byte blocks). Wire savings are derived from the frame layout of the update protocol (CoAP request and reply, AEAD framing, UDP/IP headers per exchange).*

**Table 3.** Modelled airtime for one device - app-v1.0.bin -> app-v1.1.bin *(Modelled)*

| Link | Delta (DOTA) | Full image (DOTA) | Full image (raw) |
|---|---|---|---|
| 802.15.4 (250 kbit/s) | 0.84 s | 5.70 s | 10.20 s |
| BLE-class (1 Mbit/s) | 0.21 s | 1.42 s | 2.55 s |
| Wi-Fi goodput (10 Mbit/s) | 0.02 s | 0.14 s | 0.26 s |

*Lower bound: wire bits divided by link rate; acknowledgements, retransmission, back-off and processing are excluded.*

**Table 4.** Modelled time to update a fleet on one shared channel - app-v1.0.bin -> app-v1.1.bin *(Modelled)*

| Link | Devices | Delta (DOTA) | Full image (DOTA) | Full image (raw) |
|---|---|---|---|---|
| 802.15.4 (250 kbit/s) | 1 | 0.8 s | 5.7 s | 10.2 s |
| 802.15.4 (250 kbit/s) | 10 | 8.4 s | 57.0 s | 1.7 min |
| 802.15.4 (250 kbit/s) | 100 | 1.4 min | 9.5 min | 17.0 min |
| BLE-class (1 Mbit/s) | 1 | 0.2 s | 1.4 s | 2.6 s |
| BLE-class (1 Mbit/s) | 10 | 2.1 s | 14.2 s | 25.5 s |
| BLE-class (1 Mbit/s) | 100 | 20.9 s | 2.4 min | 4.3 min |
| Wi-Fi goodput (10 Mbit/s) | 1 | 0.0 s | 0.1 s | 0.3 s |
| Wi-Fi goodput (10 Mbit/s) | 10 | 0.2 s | 1.4 s | 2.6 s |
| Wi-Fi goodput (10 Mbit/s) | 100 | 2.1 s | 14.2 s | 25.5 s |

*Proxy for bandwidth saturation: devices update one after another on a shared medium (devices x single-device airtime).*

**Observations.**

- Unfavourable cases: dummy-4B (-575.0% relative to the image), noise-64KB (-0.1% relative to the image). A delta can exceed the image when the two inputs are unrelated, as with incompressible noise.
- Every case reconstructs the target image byte for byte, using both the DOTA reference decoder and bsdiff4.

**Limitations.**

- Airtime and fleet-update durations are modelled lower bounds computed from stated link rates; they exclude acknowledgements, retransmissions and medium-access delays.
- Generation and decoding times were measured on the build host, not on the target microcontroller.

*Data files:* `sop1/cases.csv`, `sop1/cases.json`

### 3.2 Statement of the Problem 2

**Research question.** What is the quantitative reduction in computational memory overhead and transmission latency achieved by integrating the OSCORE protocol compared to standard cryptographic handshakes in constrained networks?

**Method.** Per-block AES-CCM sealing and opening (1 KiB blocks, 13-byte nonce, 16-byte tag), key set-up and the sealing of the complete update stream were timed on the gateway host (repeated operations, 95% confidence intervals). A complete TLS 1.2 handshake (ECDHE-ECDSA, certificate verified) was executed between two in-memory endpoints to obtain its CPU time, byte count and number of flights. Per-message overheads of related protocols are taken from the cited specifications. Device-side figures are included only where a serial capture or a hardware run was available.

**Principal result.** The framing adds 29 B per block and requires no handshake; a TLS 1.2 handshake costs 1,019 B in 4 flights and about 14 times the CPU time of sealing the whole update (gateway host).

**Findings.**

1. Sealing and opening one 1 KiB block with the pre-shared-key AES-CCM framing take 2.0 ± 0.1 µs (n=2000) and 2.0 ± 0.0 µs (n=2000) respectively. The framing adds 29 B per block and requires no handshake. A complete TLS 1.2 handshake (TLSv1.2, ECDHE-ECDSA-AES128-GCM-SHA256) costs 0.64 ± 0.02 ms (n=50) of CPU time and 1,019 B in 4 flights, which is about 14 times the time needed to seal the whole 24-block update. *(Measured; gateway host.)*

**Table 5.** Gateway host: crypto cost of our framing vs a TLS 1.2 handshake *(Measured)*

| Operation | Mean ± 95% CI | Median | p95 | n |
|---|---|---|---|---|
| AES-CCM seal, 1 KiB block (13 B nonce, 16 B tag) | 2.05 ± 0.08 µs (n=2000) | 1.80 | 3.00 | 2000 |
| AES-CCM open, 1 KiB block | 1.98 ± 0.03 µs (n=2000) | 1.80 | 2.30 | 2000 |
| AES-CCM key schedule (once per session/boot) | 0.35 ± 0.01 µs (n=500) | 0.30 | 0.40 | 500 |
| Seal the whole stream: 24 blocks, 23,614 B (real DOTA stream (app-v1.0.bin -> app-v1.1.bin)) | 0.05 ± 0.00 ms (n=30) | 0.04 | 0.05 | 30 |
| TLS 1.2 handshake, both ends (ECDHE-ECDSA-AES128-GCM-SHA256, X.509 verified) | 0.64 ± 0.02 ms (n=50) | 0.62 | 0.76 | 50 |
|    of which the client side | 0.42 ± 0.01 ms (n=50) | 0.41 | 0.52 | 50 |

*Timed in-process on the gateway host, not on the microcontroller. The handshake runs between two in-memory endpoints and therefore contains CPU time only, with no network time. The evaluated framing performs no handshake.*

**Table 6.** Per-message overhead and session set-up (24-block update) *(Literature)*

| Design | Per-message overhead | Bytes per message | Extra bytes for 24 messages | Session set-up | Source |
|---|---|---|---|---|---|
| Delta-OTA framing (this work, OSCORE-style) | 13 B nonce + 16 B tag | 29 B | 696 B | none: pre-shared key | Measured: frame layout of the implemented framing |
| OSCORE, RFC 8613 (AES-CCM-16-64-128) | 8 B tag + OSCORE option (flags + 1-5 B Partial IV) | 11-17 B | 264-408 B | none (key derived from a master secret) | RFC 8613, sections 5-6 (approximate: option length depends on the sequence number) |
| TLS 1.2, AES-128-GCM record | 5 B header + 8 B explicit nonce + 16 B tag | 29 B | 696 B | full handshake (measured below) | RFC 5246; RFC 5288 |
| DTLS 1.2, AES-128-GCM record | 13 B header + 8 B explicit nonce + 16 B tag | 37 B | 888 B | full handshake + cookie exchange | RFC 6347, section 4.1; RFC 5288 |

*The first row is derived from the implemented frame layout; the remaining rows are values from the cited specifications.*

**Table 7.** Network cost of one TLS 1.2 handshake (1,019 B in 4 flights); the evaluated framing has none *(Modelled)*

| Link | Handshake airtime | Airtime + 2 x 50 ms RTT (assumed) |
|---|---|---|
| 802.15.4 (250 kbit/s) | 36.2 ms | 136.2 ms |
| BLE-class (1 Mbit/s) | 9.0 ms | 109.0 ms |
| Wi-Fi goodput (10 Mbit/s) | 0.9 ms | 100.9 ms |

*Lower bound: bits divided by link rate for the measured handshake bytes plus UDP/IP headers; loss and processing are excluded.*

**Table 8.** Device side (ESP32) *(Measured)*

| Metric | Value |
|---|---|
| Static RAM of the AEAD receive path (otaEngine: two packet buffers + CCM context; excludes the DOTA decoder, see SOP 4) | 3,260 B |

*Device-side values come from the supplied serial capture and from the hardware run of SOP 4 in the same evidence run. The TLS figure is for certificate-based HTTPS, not DTLS-PSK.*

**Observations.**

- Replayed or reordered authentic blocks are not rejected by the per-block authentication of this framing (see SOP 3); a sequence number with a replay window, as in OSCORE, would reject them at the frame layer.

**Limitations.**

- The framing evaluated is an OSCORE-style AEAD framing (pre-shared key, AES-CCM, per-block nonce, no handshake). It is not an implementation of RFC 8613: it has no context derivation (HKDF), no sender sequence numbers with a replay window, no binding of release and block position into the authenticated data, and no OSCORE option encoding.
- The key is pre-shared and long-lived. There is no session-key establishment and therefore no forward secrecy; the saving measured is the handshake a standard stack would perform.
- The handshake measurement uses a minimal self-signed ECDSA certificate; certificate chains in deployment add roughly 1-3 KB, so the handshake byte count is a lower bound.
- Gateway-host timings use hardware AES acceleration and are not timings of the target microcontroller.

*Data files:* `sop2/bench.json`

### 3.3 Statement of the Problem 3

**Research question.** What is the deterministic reliability of utilizing ledger-anchored smart contracts to guarantee cryptographic authenticity and execute absolute payload revocation against compromised firmware updates?

**Method.** The evaluation has three parts. (a) The smart-contract test suite was executed on a local Hardhat network. (b) A software attack matrix injected nine classes of fault, with seeded trials, into the production verification checks (the gateway's ledger-state and SHA-256 check, the per-block AES-CCM authentication, and the end-of-transfer image digest); the layer that stopped each fault was recorded and a Wilson 95% interval computed for each detection rate. (c) A fresh local chain and the production gateway process were used to measure the rejection of unauthorized calls, the refusal of releases whose anchored hash does not match the payload, and the interval between a revocation transaction and the gateway ceasing distribution, together with the gas cost of each call.

**Principal result.** 270 of 270 injected faults were stopped; revocation halted distribution in a median of 2.5 s.

**Findings.**

1. 27 of 27 contract tests passed. They cover the fixed 2-of-3 threshold, one signature per developer per round, authorization of every caller, finality of revocation, fresh rounds on re-proposal, and the events relied on by the gateway. *(Measured.)*
2. Of 270 injected faults (9 attack types, 30 seeded trials each), 270 were stopped (detection rate of at least 98.6% at 95% confidence). The gateway layer stopped 120, the per-block authentication 90 and the end-of-transfer image digest 60. *(Measured.)*
3. 90 of 90 state-changing calls by a non-developer were rejected by the contract, and 3 of 3 releases whose anchored hash did not match the payload were refused by the gateway (never staged; devices continued to receive a refusal). *(Measured; local chain.)*
4. After a revocation transaction was sent, the gateway stopped distributing the release (it destroyed its encrypted blocks and answered devices with a revocation notice) after a median of 2.47 s (95th percentile 4.83 s, maximum 4.87 s, n=10). The bound is the gateway's 5 s poll interval plus processing. Blocks remaining on disk after the halt: 0. *(Measured; local chain.)*

**Table 9.** Smart-contract test suite (Hardhat) *(Measured)*

| Suite | Tests | Passed |
|---|---|---|
| DeltaOTA - three authors, independent consoles | 8 | 8 |
| DeltaOTA contract | 1 | 1 |
| DeltaOTA contract approving (the 2-of-3 threshold) | 5 | 5 |
| DeltaOTA contract governance parameters | 4 | 4 |
| DeltaOTA contract proposing | 5 | 5 |
| DeltaOTA contract revocation (the kill switch) | 4 | 4 |
| **Total** | 27 | 27 |

*Executed with Hardhat in 680 ms; the raw report is stored with the run.*

**Table 10.** Attack matrix (30 seeded trials per attack) *(Measured)*

| Attack | Fault injected | Stopped by | Trials | Stopped | Detection rate (95% lower bound) | Authentic frames accepted by AEAD |
|---|---|---|---|---|---|---|
| Wrong golden hash | the on-chain hash does not match the payload | gateway | 30 | 30 | 100.0% (≥ 88.6%) | 0 |
| Payload substituted | one bit of the downloaded payload is flipped | gateway | 30 | 30 | 100.0% (≥ 88.6%) | 0 |
| Revoked release | the ledger marks the release revoked | gateway | 30 | 30 | 100.0% (≥ 88.6%) | 0 |
| Not yet live | the release has not reached 2-of-3 approvals | gateway | 30 | 30 | 100.0% (≥ 88.6%) | 0 |
| Block bit-flip | one bit of a nonce/ciphertext/tag byte is flipped in transit | frame | 30 | 30 | 100.0% (≥ 88.6%) | 0 |
| Block truncated | a block frame is cut short in transit | frame | 30 | 30 | 100.0% (≥ 88.6%) | 0 |
| Frame under another key | a forger encrypts a block with a different key | frame | 30 | 30 | 100.0% (≥ 88.6%) | 0 |
| Replay of an authentic block | a valid block of an OLD release replaces one block | image | 30 | 30 | 100.0% (≥ 88.6%) | 30 |
| Reordered blocks | two authentic blocks of this release are swapped | image | 30 | 30 | 100.0% (≥ 88.6%) | 30 |

*Layers: gateway = ledger state and SHA-256 against the golden hash; frame = per-block AES-CCM tag; image = end-of-transfer image digest, modelled as the SHA-256 of the rebuilt image.*

**Table 11.** Live chain: calls the contract / gateway must refuse *(Measured)*

| Scenario | Trials | Refused | Result |
|---|---|---|---|
| Outsider proposes / approves / revokes | 90 | 90 | release untouched |
| Approved release whose on-chain hash does not match the payload | 3 | 3 | never staged; /version answers 4.01 |

**Table 12.** Revoke-to-halt latency on a local chain (n=10 revokes) *(Measured)*

| Stage | Mean ± 95% CI (ms) | Median | p95 | Min | Max |
|---|---|---|---|---|---|
| Chain confirmation (tx sent → receipt) | 14.8 ± 0.6 | 14.6 | 16.0 | 13.7 | 16.1 |
| Gateway detection (receipt → KILL SWITCH event) | 2838.1 ± 1028.8 | 2448.4 | 4803.7 | 423.4 | 4849.9 |
| Distribution halted (tx sent → first 4.03 answer) | 2859.4 ± 1028.8 | 2469.5 | 4826.0 | 446.6 | 4873.7 |

*Each revocation was sent at a seeded random point of the gateway's 5 s poll cycle, so detection is expected to be spread between 0 and 5 s. The local network produces blocks instantly, so chain confirmation understates a deployed network.*

**Table 13.** Gas per call *(Measured)*

| Call | Mean gas | Min | Max | n |
|---|---|---|---|---|
| proposeRelease | 96,361 | 81,404 | 213,876 | 10 |
| approveRelease (promotes to live) | 73,960 | 73,960 | 73,960 | 10 |
| revokeRelease | 33,518 | 33,518 | 33,518 | 10 |

*The first proposal of a version writes new storage and costs more; re-proposals after a revocation reuse it (the maximum is the first proposal).*

**Observations.**

- Replayed or reordered authentic blocks were accepted by the per-block authentication (60 of 60 trials), because the nonce is carried inside the frame and the framing does not bind a block to its release or position. These faults are stopped only by the end-of-transfer image digest. Sequence numbers with a replay window, as specified for OSCORE, would reject them at the frame layer.

**Limitations.**

- Revocation latency was measured on a local chain with instantaneous block production; a deployed network adds block-confirmation time. Detection by the gateway is bounded by its chain poll interval.
- The end-of-transfer image digest is modelled by the SHA-256 of the rebuilt image; the corresponding check on the device (esp_ota_end) is not exercised in this evaluation.

**Not performed in this run.**

- The device's own rollback after a revocation and its rejection of tampered blocks on physical flash were not measured; they require the target device.

*Data files:* `raw/mocha.json`, `raw/hardhat-test.log`, `sop3/attack_matrix.json`, `sop3/attack_matrix.csv`, `sop3/live_chain.json`, `raw/hardhat-node.log`, `raw/gateway.log`

### 3.4 Statement of the Problem 4

**Research question.** What is the measurable efficiency of offloading Web3 logic to a dedicated Edge Gateway in terms of preserving the physical memory envelope (SRAM) and processing cycles of the target node?

**Method.** Three firmware builds sharing the same ESP32 and Wi-Fi base were compared: a control (Wi-Fi only), the Delta-OTA updater, and a read-only on-device Web3 client (HTTPS, Keccak-256, a ledger query and ABI decoding) representing a lower bound of the function that offloading removes from the device. Flash and static RAM were taken from the build tool, the additional flash of the Web3 client was attributed to link-map groups, and the largest static-RAM symbols of the updater were extracted. The increments over the control were set against the Class 2 budget (250 KiB flash, 50 KiB RAM). Heap use and execution time of the on-device client were measured on the device only where a hardware run was performed.

**Principal result.** An on-device Web3 client would add 156,872 B of flash (61.3% of the Class 2 flash budget) against 43,084 B for the whole Delta-OTA updater, before any heap for TLS.

**Findings.**

1. On the same ESP32 + Wi-Fi base, the lowest-possible on-device Web3 client (HTTPS, Keccak-256, eth_call, ABI decode; read-only) adds 156,872 B of flash (61.3% of a 250 KiB Class 2 flash budget by itself) and 3,244 B of static RAM, before any heap for TLS; the whole Delta-OTA updater adds 43,084 B of flash, and the Web3 client requires 3.6 times that amount. *(Measured.)*
2. The static RAM of the updater is dominated by `g_decoder` (48,984 B, 95.7% of the 50 KiB Class 2 RAM budget on its own), which holds the DOTA decoder and its inflate dictionary. The updater adds 58,072 B of static RAM in total (113.4% of the budget). The engine-only figure (3,260 B) covers only the DeltaOTAEngine symbols and excludes this decoder. *(Measured.)*

**Table 14.** Whole-image footprint per build (PlatformIO, ESP32 + Arduino) *(Measured)*

| Build | Flash used | Static RAM used | What it is |
|---|---|---|---|
| web3_control | 724,465 B | 43,408 B | Wi-Fi only: the framework cost every build shares |
| factory (Delta-OTA updater) | 767,549 B | 101,480 B | AES-CCM block receiver + DOTA decoder + partition handling |
| web3_baseline | 881,337 B | 46,652 B | control + HTTPS + keccak256 + eth_call + ABI decode |

*These are ESP32 images, so the absolute sizes are not Class 2 sizes: the framework alone is 707.5 KB of flash. The meaningful quantity is the increment over the shared control.*

**Table 15.** Cost over the Wi-Fi-only control, against the Class 2 budget (250 KiB flash / 50 KiB RAM) *(Measured)*

| Design | Added flash | % of Class 2 flash | Added static RAM | % of Class 2 RAM |
|---|---|---|---|---|
| Delta-OTA updater (offloaded design) | +43,084 B (42.1 KB) | 16.8% | +58,072 B | 113.4% |
| On-device Web3, lower bound (no offloading) | +156,872 B (153.2 KB) | 61.3% | +3,244 B | 6.3% |

*Static RAM only. TLS buffers and handshake state live on the heap: see the hardware table below (present only when the hardware part ran).*

**Table 16.** Where the on-device Web3 flash goes (link-map groups, baseline − control) *(Measured)*

| Group | Δ flash (B) | Δ static RAM (B) |
|---|---|---|
| Other libs (newlib, drivers, glue) | +86,254 | +412 |
| mbedTLS (the TLS client stack here) | +44,480 | +548 |
| lwIP (TCP/IP) | +7,257 | +1,235 |
| App glue (setup/loop, incl. inlined engine) | +3,525 | +1,024 |
| NVS / Preferences glue | +223 | +0 |
| Arduino core | +178 | +0 |
| WiFi + UDP radio | +83 | +0 |
| FreeRTOS | +42 | +0 |

**Table 17.** Delta-OTA engine alone (symbol-attributed, factory build) *(Measured)*

| Item | Size |
|---|---|
| Engine code (flash) | 1,873 B across 10 symbols |
| Engine static RAM | 3,260 B |

*The row covers only the DeltaOTAEngine symbols; shared libraries such as the mbedTLS CCM code are not included, so the designs are compared with the increment table above.*

**Table 18.** Largest static-RAM symbols in the Delta-OTA updater (factory build) *(Measured)*

| Symbol | Size (B) | % of Class 2 RAM |
|---|---|---|
| g_decoder | 48,984 | 95.7% |
| g_copyBuf | 4,096 | 8.0% |
| g_cnxMgr | 3,800 | 7.4% |
| otaEngine | 3,260 | 6.4% |
| dns_table | 1,184 | 2.3% |
| s_wifi_nvs | 1,180 | 2.3% |
| s_coredump_stack | 1,124 | 2.2% |
| TxRxCxt | 960 | 1.9% |

**Observations.**

- The inflate dictionary accounts for most of this symbol. A smaller deflate window on the gateway, with a correspondingly smaller circular dictionary on the device, would reduce it; this was not evaluated.

**Limitations.**

- The on-device Web3 client is a lower bound: it is read-only and omits transaction signing, a JSON library and certificate validation, so a complete client would cost more.
- A comparison with a published Class 2 reference stack is not included in this edition.

**Not performed in this run.**

- Heap use and execution time of the on-device Web3 client were not measured in this run (no hardware measurement); only static sizes are reported.

*Data files:* `sop4/footprint.json`, `raw/pio-factory.log`, `raw/pio-web3_control.log`, `raw/pio-web3_baseline.log`

### 3.5 Statement of the Problem 5

**Research question.** What is the systemic performance of the synthesized Ledger Anchored Delta-OTA architecture across continuous hardware metrics (cryptographic execution time, memory allocation limits, and CoAP network latency) under automated multi-cycle testing?

Statement 5 concerns the performance of the complete architecture over 60 automated test cycles on the target hardware. It is reserved for the implementation phase that follows approval of the proposed system and is not reported in this edition. The instrumentation developed for this report (host-timestamped serial capture and parsing, summary statistics with confidence intervals, the gateway status feed and the chain driver) is the basis on which that campaign will be run.

## 4. Summary of Findings

| Statement | Principal result | Basis |
|---|---|---|
| SOP 1 | For app-v1.0.bin -> app-v1.1.bin, the update is delivered in 24 blocks instead of 158 for a full image, 85.3% less traffic on the wire. | Measured |
| SOP 2 | The framing adds 29 B per block and requires no handshake; a TLS 1.2 handshake costs 1,019 B in 4 flights and about 14 times the CPU time of sealing the whole update (gateway host). | Measured |
| SOP 3 | 270 of 270 injected faults were stopped; revocation halted distribution in a median of 2.5 s. | Measured |
| SOP 4 | An on-device Web3 client would add 156,872 B of flash (61.3% of the Class 2 flash budget) against 43,084 B for the whole Delta-OTA updater, before any heap for TLS. | Measured |
| SOP 5 | Reserved for the implementation phase (60 automated cycles) | - |

## 5. Limitations and Threats to Validity

- Modelled values (airtime, fleet-update time, handshake network cost, CPU cycles) follow from the stated assumptions and are lower bounds; they are not measurements of a deployed network.
- Timings labelled gateway-host were taken on a general-purpose computer with hardware AES acceleration and are not timings of the target microcontroller.
- Literature values are taken from the cited specifications and are approximate where the quantity depends on protocol parameters.
- *SOP 1:* Airtime and fleet-update durations are modelled lower bounds computed from stated link rates; they exclude acknowledgements, retransmissions and medium-access delays.
- *SOP 1:* Generation and decoding times were measured on the build host, not on the target microcontroller.
- *SOP 2:* The framing evaluated is an OSCORE-style AEAD framing (pre-shared key, AES-CCM, per-block nonce, no handshake). It is not an implementation of RFC 8613: it has no context derivation (HKDF), no sender sequence numbers with a replay window, no binding of release and block position into the authenticated data, and no OSCORE option encoding.
- *SOP 2:* The key is pre-shared and long-lived. There is no session-key establishment and therefore no forward secrecy; the saving measured is the handshake a standard stack would perform.
- *SOP 2:* The handshake measurement uses a minimal self-signed ECDSA certificate; certificate chains in deployment add roughly 1-3 KB, so the handshake byte count is a lower bound.
- *SOP 2:* Gateway-host timings use hardware AES acceleration and are not timings of the target microcontroller.
- *SOP 3:* Revocation latency was measured on a local chain with instantaneous block production; a deployed network adds block-confirmation time. Detection by the gateway is bounded by its chain poll interval.
- *SOP 3:* The end-of-transfer image digest is modelled by the SHA-256 of the rebuilt image; the corresponding check on the device (esp_ota_end) is not exercised in this evaluation.
- *SOP 4:* The on-device Web3 client is a lower bound: it is read-only and omits transaction signing, a JSON library and certificate validation, so a complete client would cost more.
- *SOP 4:* A comparison with a published Class 2 reference stack is not included in this edition.

**Not performed in this run:**

- *SOP 3:* The device's own rollback after a revocation and its rejection of tampered blocks on physical flash were not measured; they require the target device.
- *SOP 4:* Heap use and execution time of the on-device Web3 client were not measured in this run (no hardware measurement); only static sizes are reported.

## 6. Reproducibility

All results in this report were produced by the evidence runner included with the source code (`gateway/sop`). The runner records the software revision, library versions and the SHA-256 of every input file (Section 2); randomised trials use fixed seeds. The complete set of evaluations is run with `python -m sop all` (or `gateway\sop-run.bat`); an individual statement is run with `python -m sop sop1` to `sop4`. Raw logs and tabular data are stored beside this report in the run directory and are listed under each statement above.
