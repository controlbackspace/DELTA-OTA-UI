# sop-results: map of this folder

| Where | What |
|---|---|
| `CHAPTERS-4-AND-5-DRAFT.md` | The local draft of Chapters 4 and 5 (this folder is git-ignored; the draft is never pushed) |
| `01-raw-data/` | Everything recorded: `RUNS-INDEX.csv` (what each run is, harness, firmware, revision), `tidy-csv/` (the CSVs behind every table), the run folders in `runs/` (R), `pilots/` (P) and `discarded/` (D) with serial logs and packet captures, and `RENAMES.csv` (old to new names) |
| `02-interpretation/` | One markdown file per table in `tables/` (the approved Tables 1 to 4, Supplementary Table S2, the SOP 4 static footprint) and the seven figures in `figures/` |
| `03-writing/` | What the chapters are written from: `00_START-HERE.md`, statistical analysis, claims, limitations, scope and method, SOP evidence map, baselines, failures, defense Q&A, reproducibility |

Start with `03-writing/00_START-HERE.md`.

**Rebuild the generated files** (from `gateway/`): `python -m sop.pack build --root ../sop-results --draft ../sop-results/CHAPTERS-4-AND-5-DRAFT.md`.
**Share with the group** (a light, tracked copy without the raw evidence): `python -m sop.pack publish --root ../sop-results --dest ../testing-deliverables/thesis-data-pack`.
New runs are created in this folder as `<timestamp>/`: move them into `01-raw-data/runs/` with the next ID and add a row to `RUNS-INDEX.csv` (see `03-writing/10_reproducibility.md`).
